
// Add active class to the current button (highlight it)
