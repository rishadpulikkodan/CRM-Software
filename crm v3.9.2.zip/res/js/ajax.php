<?php
mysql_connect("localhost", "user", "pass");
mysql_select_db("database");

// Other variables needed to perform the query, such as $message_query
// needs to be here as well

while ($run_message = mysql_fetch_assoc($message_query)) {
    $from_id = $run_message['from_id'];
    $message = $run_message['message'];

    $user_query = mysql_query("SELECT `username` FROM `users` WHERE `id`='$from_id'");
    $run_user = mysql_fetch_array($user_query);
    $from_username = $run_user['username'];

    echo "<p><b>$from_username</b><br />$message</p>";
}
?>