<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[3])  
			{
				$this->load->model('Crm_model');
				date_default_timezone_set("Asia/Kolkata");
			}
		else 
			{ redirect('Crm/logout','refresh'); } 
	}

	public function index()
	{ $user = $this->session->userdata('user');
		$data['username'] = $user['username'];
		$data['id'] = $user['id'];
		$this->load->view('staff/staff',$data);
	}

	public function pendingc()
	{ $user = $this->session->userdata('user');

		echo $this->Crm_model->pendingc($user['id'])->num_rows();
	}

	public function pending()
	{
		$this->load->view('staff/pending');
	}

	public function viewpending()
	{ $user = $this->session->userdata('user');

		$rows = $this->Crm_model->getwork($user['id']);
      if($rows){
      echo "
      
		<table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
	    <thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>Type</th>
            
            <th scope='col'>name (pkg/service)</th>
            <th scope='col'>validity</th>
            <th scope='col'>pkg number</th>
            <th scope='col'>customer name</th>
            <th scope='col'>Address</th>
            <th scope='col'>Contact</th>
            <th scope='col'>Email</th>
            <th scope='col'><i class='fas'>&#xf5a0;</i> locate</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->type."</td>
            ";
            if($r->type == "service"){
 				$table = "servicereq";
				$ir = $this->Crm_model->getid($table,$r->req_id);
				if($ir)
				{
				    $s = $this->Crm_model->getsn($ir->service_id);
				    if($s){echo"<td>".$s->name."</td>";}
				    else{echo"<td style='color:red;'>! removed</td>";}
				    echo "
				    <td style='color:orange;'>! none</td>
				    <td style='color:orange;'>! none</td>
				    ";
				    $cus = $this->Crm_model->getuser($ir->custid);
				    if($cus){
						echo "
						<td>".$cus->fullname."</td>
						<td>".$cus->address."</td>
						<td>".$cus->contact."</td>
						<td>".$cus->email."</td>
						<td><a title='click to view location on Google map' href='".$cus->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>
						";
				    }
				    else{
						echo "
						<td style='color:red;'>! removed</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>";
				    }
					
				}
            }
            elseif($r->type == "package"){
				$table = "packagereq"; 
				$ir = $this->Crm_model->getid($table,$r->req_id);
				if($ir)
				{
				    echo "
				    
				    <td>".$ir->package."</td>
				    ";
				    $pk = $this->Crm_model->getpn($ir->pid);
				    if($pk){echo"<td>".$pk->validity."</td>
				    			 <td>".$pk->number."</td>
				    ";}
				    else{echo"<td style='color:red;'>! removed</td>
				    		  <td style='color:red;'>! removed</td>";}
					$cus = $this->Crm_model->getuser($ir->custid);
					if($cus){
						echo "
						<td>".$cus->fullname."</td>
						<td>".$cus->address."</td>
						<td>".$cus->contact."</td>
						<td>".$cus->email."</td>
						<td><a title='click to view location on Google map' href='".$cus->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>
						";	
					}
					else{
						echo "
						<td style='color:red;'>! removed</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>";
					}
				}
            }
            echo "
        </tr>
              ";
        }
        echo "</table>";
      } else { echo "<p align='center'>No pending works</p>"; }
	}

	public function createservicedata()
	{ $user = $this->session->userdata('user');
		$rows = $this->Crm_model->listusers(array_keys(return_privilage())[4]);
		$rows2 = $this->Crm_model->getwork($user['id']);
		if($rows2){
			echo "
			<html>
			<head>
				<meta name='viewport' content='width=device-width, initial-scale=1'>
				<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
				<link rel='stylesheet' type='text/css' href='<?= base_url()?>res/css/anim.css'>
				<link rel='stylesheet' type='text/css' href=".base_url()."res/css/crm.css'>
				<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
			</head>
			<body>
			<div class='w3-container'>
			  <div class='w3-card-4 f1 myform' style='width:75%;margin:5% auto;border-radius: 10px;'>
			    <div class='w3-container w3-blue' style='border-radius: 10px 10px 0px 0px;'>
			      <h4>Enter service data</h4>
			    </div>
			    <form class='w3-container' action='".base_url()."index.php/Staff/saveservicedata' method='POST' enctype='multipart/form-data'>
				  <p>
			    <p id='p1'>
			    <label>select my work</label>
			    <select id='s1' name='sa' class='w3-input' required>
			    <option></option>
			    ";
			    foreach($rows2 as $r)
				{
				    if($r->type == "service")
				    { $table = "servicereq";
						$ir = $this->Crm_model->getid($table,$r->req_id);
						if($ir)
						{
							$cus = $this->Crm_model->getuser($ir->custid);
							if($cus){
							    $sn = $this->Crm_model->getsn($ir->service_id)->name;
							    echo "
							    <option value='".$r->id."'>".$r->id." ".$sn." ".$r->type." from ".$cus->fullname."</option>";
							}
						}
						else{
							echo "<option>! null</option>";
						}
				    }
				    elseif($r->type == "package")
				    { $table = "packagereq"; 
						$ir = $this->Crm_model->getid($table,$r->req_id);
						if($ir)
						{
							$cus = $this->Crm_model->getuser($ir->custid);
							if($cus){
						    echo "
						    <option value='".$r->id."'>".$r->id." ".$ir->package." ".$r->type." from ".$cus->fullname."</option>";
							}
						}
						else{
							echo "<option>! null</option>";
						}
					}
				}
			    echo "
			    </select>
			    </p>
				  <p>
				  <label>Customer</label>
				  <select list='customer_id' name='customer_id' class='w3-input' required placeholder='Select Customer'>
				  	<option placeholder='Select Customer'></option>
				  ";
				  foreach($rows as $r)
				  {
				  	echo "<option value='".$r->id."'>".$r->fullname."</option>";
				  }
				  echo "
				  </select>
				  </p>
				  <p>
				  <p align='center'></p>
				  <label>Images</label>
				  <input name='upload[]' type='file' class='w3-input' accept='image/png, image/jpeg' multiple='multiple'></p>
				  <p>
				  <label>Notes</label>
				  <textarea style='min-width: 50%;max-width: 100%;min-height: 100px;max-height: 300px;' name='note' rows='2' cols='10' class='w3-input' required placeholder='Write your notes'></textarea></p>
				  <p align='center'><input class='w3-button w3-blue mybtn' style='border-radius:50px;' type='submit' value='Submit'></p>
			    </form>
			  </div>
			</div>
			</body>
			</html>
			";
		}
		else{
			echo "<p align='center'>Currently no works to you.</p>";
		}
	}

	public function saveservicedata()
	{ $user = $this->session->userdata('user');
		
		$sa = $this->input->post('sa');
		$this->Crm_model->compleated($sa);
		$cid = $this->input->post('customer_id');
		$cr = $this->Crm_model->getname($cid);
		$array = [
			'staff_name' => $user['fullname'],
			'staff_id' => $user['id'],
			'customer_name' => $cr->fullname,
			'customer_id' => $this->input->post('customer_id'),         
			'contact' => $cr->contact,
			'location' => $cr->location,
			'work_id' => $this->input->post('sa'),
			'note' => $this->input->post('note'),
			'status' => "Submitted",
			'aby' => ""
		];

		$r = $this->Crm_model->saveservicedata($array);
		if($r)
		{
			$total = count($_FILES['upload']['name']);
			for( $i=0 ; $i < $total ; $i++ )
			{
				$tmpFilePath = $_FILES['upload']['tmp_name'][$i];
				if ($tmpFilePath != "")
				{
					$newFilePath = "./res/gallery/".$_FILES['upload']['name'][$i];
					if(move_uploaded_file($tmpFilePath, $newFilePath))
					{
						$file = $_FILES['upload']['name'][$i];
						$this->Crm_model->addimg($file,$r);
					}
				}
			}
			echo "Submitted";
		}
		else{
			echo "Insert failed check the data";
		}
	}

	public function status()
	{
		$this->load->view('staff/status');
	}

	public function viewstatus()
	{ $user = $this->session->userdata('user');

		$rows = $this->Crm_model->status($user['id']);
	echo "
    <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
    <thead class='thead-dark'>";
      if($rows){
        echo "
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>service staff</th>
            <th scope='col'>staff id</th>
            <th scope='col'><i class='fas'>&#xf783;</i> date of service</th>
            <th scope='col'>service/package name</th>
            <th scope='col'>customer name</th>
            <th scope='col'>customer id</th>
            <th scope='col'><i class='fas'>&#xf879;</i> phone number</th>
            <th scope='col'><i class='fas'>&#xf5a0;</i> location</th>
            <th scope='col'>notes</th>
            <th scope='col'>status</th>
            <th scope='col'>Approved/deleted by</th>
            <th scope='col'>delete reason</th>
            <th scope='col'>reject reason</th>
            <th scope='col'>rejected/verifyed by</th>
            <th scope='col'><i class='fas'>&#xf302;</i> images</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->staff_name."</td>
            <td>".$r->staff_id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>";
            $iir = $this->Crm_model->getassrow($r->work_id);
            if($iir->type == "service"){ $table = "servicereq";

	            $iiir = $this->Crm_model->getid($table,$iir->req_id);
	            $pn = $this->Crm_model->getsn($iiir->service_id);
	            if($pn){echo"<td>".$pn->name."</td>";}
	            else{echo"<td style='color:red;'>! removed</td>";}
	        }
            elseif($iir->type == "package"){ $table = "packagereq";

	            $iiir = $this->Crm_model->getid($table,$iir->req_id);
	            $pn = $this->Crm_model->getpn($iiir->pid);
	            if($pn){echo"<td>".$pn->name."</td>";}
	            else{echo"<td style='color:red;'>! removed</td>";}
	        }
            
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
            	echo "<td>".$ir->fullname."</td>";
            }
            else{
            	echo "<td style='color:red;'>! removed user</td>";
            }
            echo "
            <td>".$r->customer_id."</td>";
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
            	if(!empty($ir->contact)) { echo "<td>".$ir->contact."</td>"; }
            	else{echo "<td style='color:red;'>null !</td>"; }
              
            	if(!empty($ir->location)) { echo "<td><a title='click to view location on Google map' href='".$ir->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>"; }
            	else{echo "<td style='color:red;'>null !</td>"; }
            }
            else{
            	echo "<td style='color:red;'>null !</td>";
            	echo "<td style='color:red;'>null !</td>";
            }
            echo "
            <td>".$r->note."</td>
            <td>".$r->status."</td>
            <td>".$r->aby."</td>
            <td>".$r->reason."</td>
            <td>".$r->rreason."</td>
            <td>".$r->vby."</td>

            <td><a href='".base_url()."index.php/Crm/images/".$r->id."'><i class='fas'>&#xf06e;</i> view</a></td>
        </tr>
              ";
        }
        echo "</table>";
      } else { echo "<p align='center'>0 results</p>"; }
	}

	public function report()
	{
		$this->load->view('staff/report');
	}

	public function viewreport()
	{ $user = $this->session->userdata('user');
		
		$rows = $this->Crm_model->servicereport($user['id']);
		if($rows){
        echo "
        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'><i class='fas'>&#xf783;</i> date of service</th>
            <th scope='col'>service/package name</th>
            <th scope='col'>number</th>
            <th scope='col'>customer name</th>
            <th scope='col'>customer id</th>
            <th scope='col'><i class='fas'>&#xf879;</i> phone number</th>
            <th scope='col'><i class='far'>&#xf249;</i> notes</th>
            <th scope='col'>status</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>";
            $iir = $this->Crm_model->getassrow($r->work_id);
            if($iir->type == "service"){ $table = "servicereq";

                $iiir = $this->Crm_model->getid($table,$iir->req_id);
                $sn = $this->Crm_model->getsn($iiir->service_id);
                if($sn){echo"<td>".$sn->name."</td><td>1</td>";}
                else{echo"<td></td><td></td>";}
            }
            elseif($iir->type == "package"){ $table = "packagereq";

                $iiir = $this->Crm_model->getid($table,$iir->req_id);
                $iiiir = $this->Crm_model->getpn($iiir->pid);
                if($iiiir){echo"<td>".$iiiir->name."</td><td>".$iiiir->number."</td>";}
                else{echo"<td></td><td></td>";}
                
            }
            
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
                echo "<td>".$ir->fullname."</td>";
            }
            else{
                echo "<td style='color:red;'>! removed user</td>";
            }
            echo "
            <td>".$r->customer_id."</td>";
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
                if(!empty($ir->contact)) { echo "<td>".$ir->contact."</td>"; }
                else{echo "<td style='color:red;'>null !</td>"; }
            }
            else{
                echo "<td style='color:red;'>null !</td>";
                echo "<td style='color:red;'>null !</td>";
            }
            echo "
            <td>".$r->note."</td>
            <td>".$r->status."</td>
        </tr>
              ";
        }
        echo "</table>";
    	}
		else{
			echo "<p align='center'>0 results</p>";
		}
		
	}

	public function edit()
	{
		$id = $this->uri->segment(3);
		$data = ['row'=>$this->Crm_model->getrow($id)];
		$this->load->view('editpass',$data);
	}

	public function dashboard()
	{
		$this->load->view('staff/dashboard');
	}
}