<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crm extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

        $this->load->helper('url');
        $this->load->library("pagination");
		$this->load->model('Crm_model');
		date_default_timezone_set("Asia/Kolkata");
	}

	public function index()
	{ if($this->session->userdata('user')){
			redirect('Crm/dashboard','refresh');
		}
		else
		{
			$this->load->view('login');
		}
	}

	public function login()
	{
			$this->load->model('Crm_model');
			if($this->Crm_model->check() === true){
				redirect('Crm/dashboard','refresh');
			}
			else{
				$data['msg']="Incorrect password";
				$this->load->view('login',$data);
			}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('Crm/index','refresh');
	}

	public function dashboard()
	{
		if($this->session->userdata('user')){
			$user = $this->session->userdata('user');
			$this->load->model('Crm_model');
			$privilage = return_privilage();
			$data['username'] = $user['username'];
			$data['id'] = $user['id'];

			if(array_keys($privilage)[0] == $user['privilage'])
			{
				$data['user'] = $user['privilage'];
				$this->load->view('admin',$data);
			}
			elseif(array_keys($privilage)[1] == $user['privilage'])
			{
				redirect('Manager','refresh');
			}
			elseif(array_keys($privilage)[2] == $user['privilage'])
			{
				redirect('Acc_exe','refresh');
			}
			elseif(array_keys($privilage)[3] == $user['privilage'])
			{
				redirect('Staff','refresh');
			}
			elseif(array_keys($privilage)[4] == $user['privilage'])
			{
				redirect('Customer','refresh');
			}
			else
			{
				$data['msg']="access denied. login first !";
				$this->load->view('login',$data);
			}
		}
		else
		{
			$data['msg']="access denied. login first !";
		    $this->load->view('login',$data);
		}
	}

	public function newuser()
	{
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$this->load->library('form_validation');
		$this->load->helper(array('form'));
		$this->load->view('signin');
	}

	 else { echo "access denied"; } }

	public function signin()
	{
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		if ($this->input->post('password') == $this->input->post('cpassword')) {

			$array = [
	                    'fullname' => $this->input->post('fullname'),
	                    'gender' => $this->input->post('gender'),
	                    'age' => $this->input->post('age'),
	                    'address' => $this->input->post('address'),
	                    'contact' => $this->input->post('contact'),
	                    'email' => $this->input->post('email'),
	                    'username' => $this->input->post('username'),
	                    'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
	                    'privilage' => $this->input->post('formselect'),
	                    'location' => $this->input->post('location'),
	                    'cby' => "Admin"
			];
					$this->load->model('Crm_model');
					$result = $this->Crm_model->signin($array);
					if($result)
					{
						echo "<p style='text-align-last:center;color:green;' class='f1'>Created successfully</p>";
					}
					else{
						$data['msg'] = "User already exist";
						$this->load->view('signin',$data);
					}
		}
		else{
			$data['msg'] = "password not mach";
			$this->load->view('signin',$data);
		}

	}

	 else { echo "access denied"; } }

	public function usermanagement()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$this->load->view('usermanagement');
	} else { echo "access denied"; } }

	public function listusers()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[2])  {

		$ur = $this->uri->segment(3);
		$data['ur'] = $ur;
		$this->load->view('listusers',$data);

	} else { echo "access denied"; } }

	public function viewlistusers()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[2])  {

		$privilage = return_privilage();
		$ur = $this->uri->segment(3);
		$this->load->database();
		$this->load->model('Crm_model');
		$rows = $this->Crm_model->listusers($ur);
		$data['ur'] = $ur;

			if($rows){
			echo "
			<table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
			<thead class='thead-light'>
			<tr>
				<th scope='col'><i class='fas'>&#xf007;</i> Full name</th>
				<th scope='col'><i class='fas'>&#xf224;</i> gender</th>
				<th scope='col'><i class='fas'>&#xf163;</i> age</th>
				<th scope='col'><i class='fas'>&#xf2bb;</i> address</th>
				<th scope='col'><i class='fa'>&#xf095;</i> contact</th>";
				if($ur == array_keys(return_privilage())[4])
				{
					echo "<th scope='col'><i class='fas'>&#xf5a0;</i> location</th>
						  <th scope='col'>created by</th>
					";
				}
				echo "<th scope='col'><i class='fa'>&#xf1d8;</i> email</th>
				<th scope='col'><i class='fas'>&#xf007;</i> username</th>
				<th scope='col' colspan='2' style='text-align:center;'><i class='fas'>&#xf4fe;</i> actions</th>
			</tr>
			</thead>
			";
			foreach($rows as $r)
			        {
			       echo "<tr>
			              <td>".$r->fullname."</td>
			              <td>".$r->gender."</td>
			              <td>".$r->age."</td>
			              <td>".$r->address."</td>
			              <td>".$r->contact."</td>";
				if($r->privilage == array_keys(return_privilage())[4])
				{
					echo "<td><a title='click to view location on Google map' href='".$r->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>";
						if($r->cby == "Admin"){
							echo "<td>Admin</td>";
						}
						else{ 
							$n = $this->Crm_model->getuser($r->cby);
							if($n){
								echo "<td>".$n->fullname."</td>";
							}
							else{
								echo "<td style='color:red;'>! removed user</td>";
							}
							
						}
						
				}
				echo "
			              <td>".$r->email."</td>
			              <td>".$r->username."</td>
			              <td align='center'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/crm/edituser/".$ur."/".$r->id."'><i class='fas'>&#xf4ff;</i> edit</a></td>
			              <td align='center'>
			              
			              	<form action='".base_url()."index.php/crm/alert/".$ur."/".$r->id."/".$r->username."' method='post' target='alert'>
 
			              		<button type='submit' id='d' class='w3-button w3-gray mybtn' value='".$ur."/".$r->id."/".$r->fullname."' type='button' onclick='deletereq()'><i class='fas'>&#xf4fa;</i> remove</button>
			              	</form>

			              </td>
			            </tr>";
			    	}
			echo "</table>
			";
			} else{ echo "<p align='center'>no users</p>"; }

	} else { echo "access denied"; } }

	public function alert()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$data['id'] = $this->uri->segment(4);
		$data['ur'] = $this->uri->segment(3);
		$data['na'] = $this->uri->segment(5);

		$this->load->view('delalert',$data);

	} else { echo "access denied"; } }

	public function removeuser()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$id = $this->uri->segment(4);
		$ur = $this->uri->segment(3);
		$this->load->database();
		$this->load->model('Crm_model');
		
		$this->Crm_model->removeusers($id);
		echo "<p id='s' align='center'>Deleted successfully</p>";

	} else { echo "access denied"; } }

	public function edituser()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$id = $this->uri->segment(4);
		$ur = $this->uri->segment(3);
		$this->load->database();
		$this->load->model('Crm_model');
		$data = ['row'=>$this->Crm_model->getrow($id)];
		$data['ur'] = $ur;
		$this->load->view('edituser',$data);
	} else { echo "access denied"; } }

	public function updateuser()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$id = $this->uri->segment(4);
		$ur = $this->uri->segment(3);
		$formdata = $this->input->post();
		$this->load->database();
		$this->load->model('Crm_model');
		$this->Crm_model->updateuser($id,$formdata);
		$data['ur'] = $ur;
		$this->load->view('listusers',$data);
		
	} else { echo "access denied"; } }

	public function createpackages()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->view('createpackages');

	} else { echo "access denied"; } }

	public function createservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->view('createservice');
	} else { echo "access denied"; } }

	public function createpackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->database();
		$this->load->model('Crm_model');
		$data = ['rows'=>$this->Crm_model->listservices()];
		$this->load->view('createpackage',$data);
	} else { echo "access denied"; } }

	public function saveservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$formdata = $this->input->post();
		$this->load->model('Crm_model');
		$result = $this->Crm_model->saveservice($formdata);
		echo "seved";
	} else { echo "access denied"; } }

	public function savepackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$formdata = $this->input->post();
		$this->load->model('Crm_model');
		$result = $this->Crm_model->savepackage($formdata);
		echo "seved";
	} else { echo "access denied"; } }

	public function listservices()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->library('Pagination_bootstrap');

		$config = array();
		$config['base_url'] = base_url().'index.php/Crm/listservices';
		$config['total_rows'] = $this->Crm_model->get_count();
		$config['per_page'] = 10;
		$config["uri_segment"] = 3;

	    $config['full_tag_open'] = '<nav aria-label="Page navigation example pagination-small pagination-sm pagination-centered"><ul class="pagination justify-content-center">';
	    $config['full_tag_close'] = '</ul></nav>';
	    $config['prev_link'] = '&lt; Prev';
	    $config['prev_tag_open'] = '<li>';
	    $config['prev_tag_close'] = '</li>';
	    $config['next_link'] = 'Next &gt;';
	    $config['next_tag_open'] = '<li>';
	    $config['next_tag_close'] = '</li>';
	    $config['cur_tag_open'] = '<li class="active"><a href="#">';
	    $config['cur_tag_close'] = '</a></li>';
	    $config['num_tag_open'] = '<li class="page-item">';
	    $config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['rows'] = $this->Crm_model->get_services($config["per_page"], $page);
		
		$this->load->view('listservices',$data);

	} else { echo "access denied"; } }

	public function editservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$id = $this->uri->segment(3);
		$data['row'] = $this->Crm_model->getsn($id);
		$this->load->view('editservice',$data);

	} else { echo "access denied"; } }

	public function modservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$formdata = $this->input->post();
			$r = $this->Crm_model->modservice($id,$formdata);
			if($r){
				$data['rows'] = $this->Crm_model->listservices();
				redirect('Crm/listservices','refresh');
			}
			else{
				echo "failed";
			}

	} else { echo "access denied"; } }

	public function deleteservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$data['row'] = $this->Crm_model->getsn($id);
			$this->load->view('deleteservice',$data);

	} else { echo "access denied"; } }

	public function dropservice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$r = $this->Crm_model->dropservice($id);
			if($r){
				$data['rows'] = $this->Crm_model->listservices();
				redirect('Crm/listservices','refresh');
			}
			else{
				echo "failed";
			}

	} else { echo "access denied"; } }

	public function listpackages()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$data['rows'] = $this->Crm_model->packages();
		$this->load->view('listpackages',$data);

	} else { echo "access denied"; } }


	public function editpackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$id = $this->uri->segment(3);
		$data['row'] = $this->Crm_model->getpn($id);
		$data['rows'] = $this->Crm_model->listservices();
		$this->load->view('editpackage',$data);

	} else { echo "access denied"; } }

	public function modpackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$formdata = $this->input->post();
			$r = $this->Crm_model->modpackage($id,$formdata);
			if($r){
				$data['rows'] = $this->Crm_model->packages();
				redirect('Crm/listpackages','refresh');
			}
			else{
				echo "failed";
			}

	} else { echo "access denied"; } }

	public function deletepackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$data['row'] = $this->Crm_model->getpn($id);
			$this->load->view('deletepackage',$data);

	} else { echo "access denied"; } }

	public function droppackage()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$r = $this->Crm_model->droppackage($id);
			if($r){
				$data['rows'] = $this->Crm_model->packages();
				redirect('Crm/listpackages','refresh');
			}
			else{
				echo "failed";
			}

	} else { echo "access denied"; } }

	public function verifications()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->view('verifications');

	} else { echo "access denied"; } }

	public function viewverifications()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->model('Crm_model');
		$rows = $this->Crm_model->verifications();
    
      if($rows){
      echo "
      <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
       <thead class='thead-dark'>
        <tr>
            <th>Slno</th>
            <th>service staff</th>
            <th>staff id</th>
            <th>date of service</th>
            <th>package name</th>
            <th>customer name</th>
            <th>customer id</th>
            <th>service data</th>
            <th colspan='2' style='text-align:center;'><i style='font-size:large;' class='material-icons'>&#xe8e8;</i> verify</th>
        </tr>
       </thead>
       ";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            ";
            $s = $this->Crm_model->getuser($r->staff_id);
            echo "
            <td>".$s->fullname."</td>
            <td>".$r->staff_id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>
            <td>".$r->work_id."</td>
            ";
            $c = $this->Crm_model->getuser($r->customer_id);
            echo "
            <td>".$c->fullname."</td>
            <td>".$r->customer_id."</td>
            <td>".$r->note."</td>

            <td><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/Crm/verify/".$r->id."'>verify</a></td>
            <td>

			              	<form action='".base_url()."index.php/crm/delalert/".$r->id."' method='post' target='alert'>
 
			              		<button type='submit' id='d' class='w3-button w3-gray mybtn' value='".$r->id."' type='button' onclick='deletereq()'> delete</button>
			              	</form>

            </td>
        </tr>";
        }
        echo "</table>";
      }
      else{
      	echo "<p align='center'>0 results</p>";
      }

	} else { echo "access denied"; } }

	public function delalert()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$data['id'] = $this->uri->segment(3);


		$this->load->view('alert',$data);

	} else { echo "access denied"; } }



	public function analytics()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$this->load->view('dashboard');

	} else { echo "access denied"; } }



	public function analyticss()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$this->load->model('Crm_model');
			$privilage = return_privilage();

			$v = $this->uri->segment(3);
			if($v == "m"){ echo $this->Crm_model->analytics(array_keys($privilage)[1])->num_rows(); }
			elseif($v == "a") { echo $this->Crm_model->analytics(array_keys($privilage)[2])->num_rows(); }
			elseif($v == "s") { echo $this->Crm_model->analytics(array_keys($privilage)[3])->num_rows(); }
			elseif($v == "c") { echo $this->Crm_model->analytics(array_keys($privilage)[4])->num_rows(); }

			elseif($v == "pw") { echo $this->Crm_model->pw()->num_rows(); }
			elseif($v == "cw") { echo $this->Crm_model->cw()->num_rows(); }
			elseif($v == "ap") { echo $this->Crm_model->ap()->num_rows(); }
			elseif($v == "as") { echo $this->Crm_model->as()->num_rows(); }
			elseif($v == "rs") { 
				$s = $this->Crm_model->servicereqc()->num_rows();
				$p = $this->Crm_model->packagereqc()->num_rows();
				$c = $s + $p;
				echo $c;
			}
			elseif($v == "bar")
			{
				$sqs = $this->Crm_model->all_count("servicereq");
				$pqs = $this->Crm_model->all_count("packagereq");

				$total = $sqs + $pqs;

				$com = $this->Crm_model->cw()->num_rows();
				$pen = $this->Crm_model->pw()->num_rows();
				$dlt = $this->Crm_model->all_countw("requests","status","Deleted")->num_rows();

				$ppen = ($pen / 100) * $total;
				$pcom = ($com / 100) * $total;
				$pdlt = ($dlt / 100) * $total;

				echo "
			  <div class='barcontainerheader'>
			    
			  </div>
			  
			  <div class='bar' style='height: ".$pcom."%'>
				".$pcom."
			    <div class='barlabel'>
			      ".$com."
			    </div>
			  </div>

			  <div class='bar' style='height:".$ppen."%'>
			    ".$ppen."
			    <div class='barlabel'>
			      ".$pen."
			    </div>
			  </div>

			  <div class='bar' style='height:".$pdlt."%'>
			    ".$pdlt."
			    <div class='barlabel'>
			      ".$dlt."
			    </div>
			  </div>

			  <div class='bar' style='height:100%'>
			    ".$total."
			    <div class='barlabel'>
			      ".$total."
			    </div>
			  </div>
			";
			}

	} else { echo "access denied"; } }

	public function requests()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$this->load->model('Crm_model');
			echo "Verifications (".$this->Crm_model->requests()->num_rows().")";

	} else { echo "access denied"; } }

	public function verify()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {
			if ($user['privilage'] == array_keys(return_privilage())[0]) {
				$vby = "Admin ".$user['username'];
			}
			elseif($user['privilage'] == array_keys(return_privilage())[1]){
				$vby = "Manager ".$user['username'];
			}
			$id = $this->uri->segment(3);
			$this->Crm_model->verify($id,$vby);
			$this->load->view('verifications');

	} else { echo "access denied"; } }

	public function reject()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			if ($user['privilage'] == array_keys(return_privilage())[0]) {
				$vby = "Admin ".$user['username'];
			}
			elseif($user['privilage'] == array_keys(return_privilage())[1]){
				$vby = "Manager ".$user['username'];
			}
			$id = $this->uri->segment(3);
			$reason = $this->input->post('reason');
			$this->Crm_model->reject($id,$vby,$reason);
			echo "<p id='s' style='display:none;' align='center'>Rejected successfully</p>";

	} else { echo "access denied"; } }

	public function images()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1] OR $user['privilage'] == array_keys(return_privilage())[2] OR $user['privilage'] == array_keys(return_privilage())[3])  {

		$id = $this->uri->segment(3);
		$data = ['rows' => $this->Crm_model->images($id)];
		$this->load->view('images',$data);

	} else { echo "access denied"; } }

	public function edit()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$id = $this->uri->segment(3);
		$data = ['row'=>$this->Crm_model->getrow($id)];
		$this->load->view('edit',$data);
		
	} else { echo "access denied"; } }

	public function edita()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])
		{
		$id = $this->uri->segment(3);
		$op = $this->input->post('op');
		$np = $this->input->post('np');
		$cnp = $this->input->post('cnp');
		$row = $this->Crm_model->getrow($id);
		$data['row'] = $this->Crm_model->getrow($id);
		if (password_verify($op, $row->password)) {
			if ($np == $cnp) {
                $a = $this->input->post('fullname');
                $b = $this->input->post('gender');
                $c = $this->input->post('age');
                $d = $this->input->post('address');
                $e = $this->input->post('contact');
                $f = $this->input->post('email');
                $h = password_hash($cnp, PASSWORD_DEFAULT);
                $this->load->database();
				$this->load->model('Crm_model');
				$this->Crm_model->edita($id,$a,$b,$c,$d,$e,$f,$h);

				$this->session->sess_destroy();

				echo "
				<script type='text/javascript'>
				parent.window.location.reload();
				</script>
				";

			}
			else{
				$data['msg'] = "New password not mach";
				$this->load->view('edit',$data);
			}
		}
		else{
			$data['msg'] = "Old password not mach";
			$this->load->view('edit',$data);
		}
		
	} else { echo "access denied"; } }

	public function editpass()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[1] OR
					$user['privilage'] == array_keys(return_privilage())[2] OR
					$user['privilage'] == array_keys(return_privilage())[3] OR
					$user['privilage'] == array_keys(return_privilage())[4]
		  ){
		  	
		$id = $this->uri->segment(3);
		$op = $this->input->post('op');
		$np = $this->input->post('np');
		$cnp = $this->input->post('cnp');
		$row = $this->Crm_model->getrow($id);
		$data['row'] = $this->Crm_model->getrow($id);
		if (password_verify($op, $row->password)) {
			if ($np == $cnp) {
                $h = password_hash($cnp, PASSWORD_DEFAULT);
                $this->load->database();
				$this->load->model('Crm_model');
				$this->Crm_model->editpass($id,$h);
				$this->session->sess_destroy();
				echo "
				<script type='text/javascript'>
				parent.window.location.reload();
				</script>
				";
			}
			else{
				$data['msg'] = "New password not mach";
				$this->load->view('editpass',$data);
			}
		}
		else{
			$data['msg'] = "Old password not mach";
			$this->load->view('editpass',$data);
		}
		
	} else { echo "access denied"; } }

	public function invoices()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$this->load->view('invoices');
			
	} else { echo "access denied"; } }

	public function listinvoices()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$data['custs'] = $this->Crm_model->invocus();
			$this->load->view('listinvoices',$data);

	} else { echo "access denied"; } }

	public function reports()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

			$this->load->view('reports');

	} else { echo "access denied"; } }

	public function viewreports()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0])  {

		$config = array();
		$config['base_url'] = base_url().'index.php/Crm/viewreports';
		$config['total_rows'] = $this->Crm_model->all_count("requests");
		$config['per_page'] = 10;
		$config["uri_segment"] = 3;
		$this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $links = $this->pagination->create_links();

        $rows = $this->Crm_model->get_requests($config["per_page"], $page);

			if($rows){
        echo "
        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
		<thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>service staff</th>
            <th scope='col'>staff id</th>
            <th scope='col'><i class='fas'>&#xf073;</i> date of service</th>
            <th scope='col'>service/package name</th>
            <th scope='col'>customer name</th>
            <th scope='col'>customer id</th>
            <th scope='col'><i class='fa'>&#xf095;</i> phone number</th>
            <th scope='col'><i class='fas'>&#xf5a0;</i> Location</th>
            <th scope='col'><i class='fa'>&#xf15c;</i> notes</th>
            <th scope='col'><i class='glyphicon'>&#xe185;</i>status</th>
            <th scope='col'>Approved/deleted by</th>
            <th scope='col'>delete reason</th>
            <th scope='col'>reject reason</th>
            <th scope='col'>rejected/verifyed by</th>
            <th scope='col'><i class='fas'>&#xf302;</i> images</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->staff_name."</td>
            <td>".$r->staff_id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>";
            $iir = $this->Crm_model->getassrow($r->work_id);
            if($iir->type == "service"){ $table = "servicereq";

	            $iiir = $this->Crm_model->getid($table,$iir->req_id);
	            $pn = $this->Crm_model->getsn($iiir->service_id);
	            if($pn){echo"<td>".$pn->name."</td>"; }
	            else{echo"<td></td>";}
	            
	        }
            elseif($iir->type == "package"){ $table = "packagereq";

	            $iiir = $this->Crm_model->getid($table,$iir->req_id);
	            $pk = $this->Crm_model->getpn($iiir->pid);
	            if($pk){echo"<td>".$pk->name."</td>";}
	            else{echo"<td></td>";}
	        }
            
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
            	echo "<td>".$ir->fullname."</td>";
            }
            else{
            	echo "<td style='color:red;'>! removed user</td>";
            }
            echo "
            <td>".$r->customer_id."</td>";
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
            	if(!empty($ir->contact)) { echo "<td>".$ir->contact."</td>"; }
            	else{echo "<td style='color:red;'>null !</td>"; }
              
            	if(!empty($ir->location)) { echo "<td><a title='click to view location on Google map' href='".$ir->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>"; }
            	else{echo "<td style='color:red;'>null !</td>"; }
            }
            else{
            	echo "<td style='color:red;'>null !</td>";
            	echo "<td style='color:red;'>null !</td>";
            }
            echo "
            <td>".$r->note."</td>
            <td>".$r->status."</td>
            <td>".$r->aby."</td>
            <td>".$r->reason."</td>
            <td>".$r->rreason."</td>
            <td>".$r->vby."</td>

            <td><a href='".base_url()."index.php/Crm/images/".$r->id."'><i class='fas'>&#xf06e;</i> view</a></td>
        	</tr>
              ";
			}
			echo "</table>";
			}
			else{
				echo "<p align='center'>0 results</p>";
			}

			echo "<p align='center'>".$links."</p>";

	} else { echo "access denied"; } }

	public function createinvoicephp()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$data['users'] = $this->Crm_model->invoices();
			$data['pkgs'] = $this->Crm_model->packages();
			$data['servs'] = $this->Crm_model->listservices();
			$count = $this->Crm_model->invocount();
			if($count)
			{
				foreach ($count as $r)
				{
					$c = $r->count;
					$inc = $c + 1;
					$res = $this->Crm_model->inc($r->count,$inc);
					$data['count'] = $inc;
					$this->load->view('createinvoicephp',$data);
				}
			}

	} else { echo "access denied"; } }

	public function getuser()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			if($id)
			{

				$u = $this->Crm_model->getuser($id);
				if($u)
				{
					echo "<text class='f1'>
					<b>&nbsp;&nbsp;&nbsp;<u>To</u></br>
					<b>Name : </b>".$u->fullname."</br>
					<b>id : </b>".$u->id."</br>
					<b>date : </b>".date("d-m-Y")."</br>
					<b>Phone : </b>".$u->contact."</br>
					<b>Address : </b>".$u->address."</br>
					</text>
					";
				}
			}

	} else { echo "access denied"; } }

	public function getpkg()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			if($id)
			{
				$pkg = $this->Crm_model->getpn($id);
				if($pkg)
				{
					echo "
					<tr>
						<td>".$pkg->id."</td>
						<td>".$pkg->name."</td>
						<td>".$pkg->price."</td>
						<td><button id='".$pkg->id."'>remove</button></td>
					</tr>
					";
				}
			}

	} else { echo "access denied"; } }

	public function addinvo()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$ur = $this->uri->segment(3);
			if($ur == "p")
			{
				$id = $this->uri->segment(5);
				$gst = $this->uri->segment(6);
				$pkg = $this->Crm_model->getpn($id);
				if($pkg)
				{
				$array = [
		            'cus_id' => $this->uri->segment(4),
		            'type' => "package",
		            'name' => $pkg->name,
		            // 'price' => $pkg->price,
		            'price' => $this->uri->segment(8),
		            'invo_id' => $this->uri->segment(7)
		        ];
		        $this->Crm_model->insert("invoices_details",$array);
				}
			}
			elseif($ur == "s")
			{
				$id = $this->uri->segment(5);
				$gst = $this->uri->segment(6);
				$srv = $this->Crm_model->getsn($id);
				if($srv)
				{
				$array = [
		            'cus_id' => $this->uri->segment(4),
		            'type' => "service",
		            'name' => $srv->name,
		            // 'price' => $srv->price,
		            'price' => $this->uri->segment(8),
		            'invo_id' => $this->uri->segment(7)
		        ];
		        $this->Crm_model->insert("invoices_details",$array);
				}
			}
			elseif($ur == "e")
			{
				$array = [
		            'cus_id' => $this->uri->segment(4),
		            'type' => "expence",
		            'name' => $this->uri->segment(5),
		            'price' => $this->uri->segment(6),
		            'invo_id' => $this->uri->segment(7)
		        ];
		        $this->Crm_model->insert("invoices_details",$array);
			}

	} else { echo "access denied"; } }

	public function loadinvoices()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

		$count = $this->uri->segment(3);
		$rows = $this->Crm_model->getinvo($count);

		if($rows){
        echo "
        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
		<thead>
        <tr>
            <th scope='col'>Service name</th>
            <th scope='col'>Type</th>
            <th scope='col'>Price</th>
            <th scope='col' class='rm'></th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        	echo"
        	<tr>
        		<td>".$r->name."</td>
        		<td>".$r->type."</td>
        		<td>".$r->price."</td>
        		<td align='right' class='rm'>"; ?> <button class='rmo btn btn-primary' onclick="reminvo('<?=$r->id?>')">remove</button> <?php echo"</td>
        	</tr>
        	";
        }
    	}

	} else { echo "access denied"; } }

	public function removeinvoice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$this->Crm_model->removeinvoice($id);

	} else { echo "access denied"; } }

	public function invoid()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$this->load->database();
			$last = $this->Crm_model->invoid();
			if($last)
			{
				echo $last;
			}

	} else { echo "access denied"; } }

	public function invoicetotal()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			if($this->uri->segment(4) == "gst"){
				$id = $this->uri->segment(3);
				$rows = $this->Crm_model->invoicetotal($id);
				$t = 0;
				foreach($rows as $r){ $t = $t + $r->price; }
				$gst = $t * 18 / 100;
				$gtotal = $t + $gst;
				echo $gtotal;
			}
			elseif($this->uri->segment(4) == "sc")
			{
				$id = $this->uri->segment(3);
				$rows = $this->Crm_model->invoicetotal($id);
				$t = 0;
				foreach($rows as $r){ $t = $t + $r->price; }
				$gst = $t * 18 / 100;
				$sgst = $gst / 2;
				echo"<br/>
		            SGST : ".$sgst."<br/>
		            CGST : ".$sgst."<br/>";
			}
			else{
				$id = $this->uri->segment(3);
				$rows = $this->Crm_model->invoicetotal($id);
				$t = 0;
				foreach($rows as $r){ $t = $t + $r->price; }
				echo $t;
			}

	} else { echo "access denied"; } }

	public function saveinvoice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$cus = $this->Crm_model->getrow($this->uri->segment(3));
			$array = [
		    	'cus_id' => $this->uri->segment(3),
		        'cus_name' => $cus->fullname,
		        'total' => $this->uri->segment(4),
		        'invo_id' => $this->uri->segment(5)
		    ];
		    $this->Crm_model->insert("invoices",$array);

	} else { echo "access denied"; } }

	public function viewsubinvo()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$data['row'] = $this->Crm_model->tablewhere("invoices","cus_id",$id);
			$data['cusid'] = $id;
			if($data['row'])
			{
				$this->load->view('invoicelist',$data);
			}
			else{ echo "0 results"; }

	} else { echo "access denied"; } }

	public function invoicesdetails()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$data['id'] = $id;
			$data['cus'] = $this->Crm_model->getid("users",$this->uri->segment(4));
			$row = $this->Crm_model->tablewhere("invoices_details","invo_id",$id);
			$data['row'] = $row;
			if($row){
				$this->load->view('invoicesdetails',$data);
			}
			else { echo "0 results"; }

	} else { echo "access denied"; } }

	public function viewinvoicesdetails()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$id = $this->uri->segment(3);
			$row = $this->Crm_model->tablewhere("invoices_details","invo_id",$id);
			$data['row'] = $row;
			if($row){
	        echo "
	        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
			<thead>
	        <tr>
	            <th scope='col'>Name</th>
	            <th scope='col'>Type</th>
	            <th scope='col'>Price</th>
	        </tr>
	        </thead>";
			foreach($row as $r)
			{
					echo "
					<tr>
						<td>".$r->name."</td>
						<td>".$r->type."</td>
						<td>".$r->price."</td>
					</tr>
					";
			}
			echo "</table>";
			}

	} else { echo "access denied"; } }

	public function editinvoice()
	{	$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[0] OR $user['privilage'] == array_keys(return_privilage())[1])  {

			$invoid = $this->uri->segment(3);
			$data['pkgs'] = $this->Crm_model->packages();
			$data['servs'] = $this->Crm_model->listservices();
			$data['cus'] = $this->uri->segment(4);
			$data['rows'] = $this->Crm_model->tablewhere("invoices_details","invo_id",$invoid);
			if($data['rows'])
			{
				$this->load->view('editinvoice',$data);
			}

	} else { echo "access denied"; } }

}