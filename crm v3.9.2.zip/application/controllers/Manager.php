<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manager extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[1])  {

			$this->load->model('Crm_model');
			date_default_timezone_set("Asia/Kolkata");

	} else { 
		redirect('Crm/logout','refresh');
		 } }

	public function index()
	{ $user = $this->session->userdata('user');

			$this->load->model('Crm_model');
			$privilage = return_privilage();

			$mgrs = $this->Crm_model->analytics(array_keys($privilage)[1]);
			$acc_exes = $this->Crm_model->analytics(array_keys($privilage)[2]);
			$staffs = $this->Crm_model->analytics(array_keys($privilage)[3]);
			$customers = $this->Crm_model->analytics(array_keys($privilage)[4]);

			$data['username'] = $user['username'];
			$data['id'] = $user['id'];

			$data['mgrs'] = $mgrs->num_rows();
			$data['acc_exes'] = $acc_exes->num_rows();
			$data['staffs'] = $staffs->num_rows();
			$data['customers'] = $customers->num_rows();

		$this->load->view('manager/manager',$data);
	}

	public function edit()
	{
		$id = $this->uri->segment(3);
		$data = ['row'=>$this->Crm_model->getrow($id)];
		$this->load->view('editpass',$data);
	}

}