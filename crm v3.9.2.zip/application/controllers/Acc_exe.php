<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Acc_exe extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[2] OR array_keys(return_privilage())[0] OR array_keys(return_privilage())[1])  {

		$this->load->model('Crm_model');
		date_default_timezone_set("Asia/Kolkata");

	} else { redirect('Crm/logout','refresh'); } }

	public function index()
	{ $user = $this->session->userdata('user');
		$data['username'] = $user['username'];
		$data['id'] = $user['id'];
		$this->load->view('acc_exe/acc_exe',$data);
	}
	public function approvalc()
	{
		echo "Approvals (".$this->Crm_model->approvalc()->num_rows().")";
	}

	public function nreqc()
	{
		$s = $this->Crm_model->servicereqc()->num_rows();
		$p = $this->Crm_model->packagereqc()->num_rows();
		$c = $s + $p;
		echo "Requests (".$c.")";
	}

	public function cc()
	{ $user = $this->session->userdata('user');
		echo $this->Crm_model->cc($user['id'])->num_rows();
	}

	public function sc()
	{ $user = $this->session->userdata('user');
		echo $this->Crm_model->sc($user['id'])->num_rows();
	}

	public function servicereqc()
	{
		echo "Service requests (".$this->Crm_model->servicereqc()->num_rows().")";
	}

	public function packagereqc()
	{
		echo "Package requests (".$this->Crm_model->packagereqc()->num_rows().")";
	}

	public function approvals()
	{
		$this->load->view('acc_exe/approvals');
	}

	public function viewapprovals()
	{ $user = $this->session->userdata('user');
		$rows = $this->Crm_model->approvals();
		$username = $user['username'];
	echo "
	
    <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
    <thead class='thead-light'>";
      if($rows){
        echo "
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>date of service</th>
            <th scope='col'>service staff</th>
            <th scope='col'>staff id</th>
            <th scope='col'>customer name</th>
            <th scope='col'>customer id</th>
            <th scope='col'>package name</th>
            <th scope='col'>note</th>
            <th scope='col'>image</th>
            <th scope='col'>approve</th>
            <th scope='col'>delete</th>
        </tr>
        </thead>";
        
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>
            <td>".$r->staff_name."</td>
            <td>".$r->staff_id."</td>
            <td>".$r->customer_name."</td>
            <td>".$r->customer_id."</td>
            <td>".$r->work_id."</td>
            <td>".$r->note."</td>
            <td><a href='".base_url()."index.php/Crm/images/".$r->id."'>view</a></td>
            <td><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/Acc_exe/approve/".$r->id."/".$username."'>approve</a></td>
            <td>
			              	<form action='".base_url()."index.php/Acc_exe/delalert/".$r->id."' method='post' target='alert'>
 
			              		<button type='submit' id='d' class='w3-button w3-gray mybtn' value='".$r->id."' type='button' onclick='deletereq()'> delete</button>
			              	</form>
            </td>
        </tr>

              ";
        }
        echo "</table>
    	";
      } else { echo "<p align='center'>0 results</p>"; }

	}

	public function approve()
	{
		$id = $this->uri->segment(3);
		$aby = $this->uri->segment(4);
		$this->Crm_model->approve($id,$aby);
		$this->load->view('acc_exe/approvals');
	}

	public function delalert()
	{
		$data['id'] = $this->uri->segment(3);
		$this->load->view('acc_exe/alert',$data);
	}

	public function delete()
	{ $user = $this->session->userdata('user');

		$id = $this->uri->segment(3);
		$aby = $user['username'];
		$reason = $this->input->post('reason');
		$this->Crm_model->delete($id,$aby,$reason);
		echo "<p id='s' style='display:none;' align='center'>Rejected successfully</p>";
	}

	public function customers()
	{
		$this->load->view('acc_exe/customers');
	}

	public function createcustomer()
	{
		$this->load->view('acc_exe/createcustomer');
	}

	public function signinc()
	{ $user = $this->session->userdata('user');

		$p = password_hash($this->input->post('password'), PASSWORD_DEFAULT);

		$sp = $this->input->post('password');
		$cp = $this->input->post('cpassword');
		if ($sp == $cp) {

		$array = [
                    'fullname' => $this->input->post('fullname'),
                    'gender' => $this->input->post('gender'),
                    'age' => $this->input->post('age'),
                    'address' => $this->input->post('address'),
                    'contact' => $this->input->post('contact'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => $p,
                    'privilage' => array_keys(return_privilage())[4],
                    'location' => $this->input->post('location'),
                    'cby' => $user['id']
		];
					$this->load->model('Crm_model');
					$result = $this->Crm_model->signin($array);
					if($result)
					{
						echo "success";
					}
					else{
						$data['msg'] = "User already exist";
						$this->load->view('signin',$data);
					}
		}
		else{
			$data['msg'] = "password not mach";
			$this->load->view('signin',$data);
		}
	}

	public function clistusers()
	{
		$ur = $this->uri->segment(3);
		$data['ur'] = $ur;
		$this->load->view('acc_exe/clistusers',$data);
	}

	public function viewclistusers()
	{ $user = $this->session->userdata('user');
		$privilage = return_privilage();
		$ur = $this->uri->segment(3);
		$rows = $this->Crm_model->clistusers($ur,$user['id']);
		$data['ur'] = $ur;

			if($rows){
			echo "
			<table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
			<thead class='thead-light'>
			<tr>
				<th scope='col'><i class='fas'>&#xf007;</i> Full name</th>
				<th scope='col'><i class='fas'>&#xf224;</i> gender</th>
				<th scope='col'><i class='fas'>&#xf163;</i> age</th>
				<th scope='col'><i class='fas'>&#xf2bb;</i> address</th>
				<th scope='col'><i class='fa'>&#xf095;</i> contact</th>
				";
				if($ur == array_keys(return_privilage())[4])
				{
					echo "<th scope='col'><i class='fas'>&#xf5a0;</i> location</th>";
				}
				echo "
				<th scope='col'><i class='fa'>&#xf1d8;</i> email</th>
				<th scope='col'><i class='fas'>&#xf007;</i> username</th>
			</tr>
			</thead>
			";
			foreach($rows as $r)
			        {
			       echo "<tr>
			              <td>".$r->fullname."</td>
			              <td>".$r->gender."</td>
			              <td>".$r->age."</td>
			              <td>".$r->address."</td>
			              <td>".$ir->contact."</td>";
				if($r->privilage == array_keys(return_privilage())[4])
				{
					echo "<td><a title='click to view location on Google map' href='".$r->location."' target='_blank'><i class='fas'>&#xf3c5;</i> map</a></td>";
				}
				echo "
			              <td>".$r->email."</td>
			              <td>".$r->username."</td>
			            </tr>";
			    	}
			echo "</table>
			";
			} else{ echo "<p align='center'>No customers created by you</p>"; }
	}

	public function requests()
	{
		$this->load->view('acc_exe/requests');
	}

	public function servicerequests()
	{
		$this->load->view('acc_exe/servicerequests');
	}

	public function packagerequests()
	{
		$this->load->view('acc_exe/packagerequests');
	}

	public function viewservicerequests()
	{
	$rows = $this->Crm_model->servicerequests();
    if($rows){
    echo "
    <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
    <thead class='thead-dark'>
        <tr>
            <th>Slno</th>
            <th>date</th>
            <th>Customer</th>
            <th>Cust ID</th>
            <th><i class='fa'>&#xf095;</i> Phone</th>
            <th>Service</th>
        </tr>
    </thead>";
        foreach($rows as $r)
        {
		$dt = new DateTime($r->date);
		$cdt = $dt->format('Y-m-d');
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>
            ";
            $ir = $this->Crm_model->getuser($r->custid);
            if($ir){
            	echo "<td>".$ir->fullname."</td>";
            }
            else{
            	echo "<td style='color:red;'>! removed user</td>";
            }
            echo "
            <td>".$r->custid."</td>
            <td>".$ir->contact."</td>
            ";
            $ir = $this->Crm_model->servicerow($r->service_id);
            if($ir){
            	echo "<td>".$ir->name."</td>";
            }
            else{
            	echo "<td style='color:red;'>! null</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
      } else { echo "<p align='center'>No servicerequests</p>"; }
	}

	public function viewpackagerequests()
	{
		$rows = $this->Crm_model->packagerequests();
      if($rows){
        echo "
    <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
    <thead class='thead-dark'>
        <tr>
            <th>Slno</th>
            <th>date</th>
            <th>Customer</th>
            <th>Cust ID</th>
            <th><i class='fa'>&#xf095;</i> Phone</th>
            <th>Package</th>
        </tr>
    </thead>";
        foreach($rows as $r)
        {
		$dt = new DateTime($r->date);
		$cdt = $dt->format('Y-m-d');
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".date('d-F-Y', strtotime($r->date))."</td>
            ";
            $ir = $this->Crm_model->getuser($r->custid);
            if($ir){
            	echo "<td>".$ir->fullname."</td>";
            }
            else{
            	echo "<td style='color:red;'>! removed user</td>";
            }
            echo"
            <td>".$r->custid."</td>
            <td>".$ir->contact."</td>
            ";
            $ir = $this->Crm_model->pid($r->pid);
            if($ir){
            	echo "<td>".$ir->name."</td>";
            }
            else{
            	echo "<td style='color:red;'>! null</td>";
            }
            echo "
        </tr>
              ";
        }
        echo "</table>";
      } else { echo "<p align='center'>No packagerequests</p>"; }
	}

	public function assign()
	{
		$data['rows'] = $this->Crm_model->listusers(array_keys(return_privilage())[3]);
		$data['s'] = $this->Crm_model->servicerequests();
		$data['p'] = $this->Crm_model->packagerequests();
		if($data['s']){$this->load->view('acc_exe/assign',$data);}
		elseif($data['p']){$this->load->view('acc_exe/assign',$data);}
		else{echo"
		<link rel='stylesheet' type='text/css' href='".base_url()."res/css/anim.css'>
		<p class='f1' style='font-family: sans-serif;
    border: solid 0.5px orange;
    padding: 15px;
    border-radius: 20px;
    width: 50%;
    margin: auto;
    background-color: hsla(40, 98%, 90%, 1);
    color: hsla(40, 98%, 35%, 1);' align='center'>All works are asssigned.<br/>
		No service or package requests from any custommer !</p>";}
	}

	public function saveassign()
	{ $user = $this->session->userdata('user');
		$r = $this->input->post('r');
		if($r == "service"){
			if($this->input->post('sa')){
				$s = $this->input->post('sa');
				$array = [
		            'type' => $this->input->post('r'),
		            'req_id' => $s,
		            'staff_id' => $this->input->post('staff_id'),
		            'status' => "assigned",
		            'aby' => $user['id']
				];
						$table = "servicereq";
						$result = $this->Crm_model->assign($array,$table,$s);
						if($result)
						{
							$data['msg'] = "<p style='color:green;'>Assigned</p>";
							$data['rows'] = $this->Crm_model->listusers(array_keys(return_privilage())[3]);
							$data['s'] = $this->Crm_model->servicerequests();
							$data['p'] = $this->Crm_model->packagerequests();
							if($data['s']){$this->load->view('acc_exe/assign',$data);}
							elseif($data['p']){$this->load->view('acc_exe/assign',$data);}
							else{echo"<p align='center'>Assigned</p>";}
						}
						else{
							echo "fail_a";
						}
			}
			else{
				$data['msg'] = "<p style='color:red;'>select service</p>";
				$data['rows'] = $this->Crm_model->listusers(array_keys(return_privilage())[3]);
				$data['s'] = $this->Crm_model->servicerequests();
				$data['p'] = $this->Crm_model->packagerequests();
				$this->load->view('acc_exe/assign',$data);
			}
		}
		elseif($r == "package"){
			if($this->input->post('sb')){
				$s = $this->input->post('sb');
				$array = [
		            'type' => $this->input->post('r'),
		            'req_id' => $s,
		            'staff_id' => $this->input->post('staff_id'),
		            'status' => "assigned",
		            'aby' => $user['id']
				];
						$table = "packagereq";
						$result = $this->Crm_model->assign($array,$table,$s);
						if($result)
						{
							$data['msg'] = "<p style='color:green;'>Assigned</p>";
							$data['rows'] = $this->Crm_model->listusers(array_keys(return_privilage())[3]);
							$data['s'] = $this->Crm_model->servicerequests();
							$data['p'] = $this->Crm_model->packagerequests();
							if($data['s']){$this->load->view('acc_exe/assign',$data);}
							elseif($data['p']){$this->load->view('acc_exe/assign',$data);}
							else{echo"<p align='center'>Assigned</p>";}
						}
						else{
							echo "fail_b";
						}
			}
			else{
				$data['msg'] = "<p style='color:red;'>select package</p>";
				$data['rows'] = $this->Crm_model->listusers(array_keys(return_privilage())[3]);
				$data['s'] = $this->Crm_model->servicerequests();
				$data['p'] = $this->Crm_model->packagerequests();
				$this->load->view('acc_exe/assign',$data);
			}
		}
		else{
			echo "string";
		}

	}

	public function edit()
	{
		$id = $this->uri->segment(3);
		$data = ['row'=>$this->Crm_model->getrow($id)];
		$this->load->view('editpass',$data);
	}

	public function dashboard()
	{
		$this->load->view('acc_exe/dashboard');
	}

}