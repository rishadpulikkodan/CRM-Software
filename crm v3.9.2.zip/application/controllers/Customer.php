<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$user = $this->session->userdata('user');
		if($user && $user['privilage'] == array_keys(return_privilage())[4])  {

			$this->load->model('Crm_model');
            date_default_timezone_set("Asia/Kolkata");

	} else { redirect('Crm/logout','refresh'); } }

	public function index()
	{ $user = $this->session->userdata('user');
		$data['username'] = $user['username'];
        $data['id'] = $user['id'];
		$this->load->view('customer/customer',$data);
	}

	public function dashboard()
	{
		$this->load->view('customer/dashboard');
	}

    public function analytics()
    { $user = $this->session->userdata('user');

        $v = $this->uri->segment(3);

        if($v == "pk"){ echo $this->Crm_model->ap()->num_rows(); }
        elseif($v == "ss"){ echo $this->Crm_model->as()->num_rows(); }
        elseif($v == "sh"){ echo $this->Crm_model->sh($user['id'])->num_rows(); }
        elseif($v == "ps")
            {
                $pp = $this->Crm_model->pp($user['id'])->num_rows();
                $ps = $this->Crm_model->ps($user['id'])->num_rows();
                $tt = $pp + $ps;
                echo $tt;
            }
    }

    public function services()
    {
        $this->load->view('customer/services');
    }

    public function viewservices()
    {
        $rows = $this->Crm_model->listservices();
        if($rows){
        echo "
        <h4 align='center' width='100%'>Availed services</h4>
        <table style='background-color:#e7f2fd;white-space:nowrap;' class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
            <tr>
                <th scope='col'>Service name</th>
                <th scope='col'><i class='fas'>&#xf156;</i> price</th>
                <th class='align-right' align='right' scope='cil'>action</th>
            </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->name."</td>
            <td><i class='fas'>&#xf156;</i>".$r->price."</td>
            <td class='align-right' align='right'><a class='w3-button w3-gray mybtn' href='". base_url()."index.php/Customer/savereqservice/req/".$r->id."'><i style='font-size:large;' class='material-icons'>&#xe163;</i> request</a></td>
        </tr>
              ";
        }
        echo "</table>";
      } else { echo "<p align='center'>No packages</p>"; }
    }

    public function packages()
    {
        $this->load->view('customer/packages');
    }

	public function viewpackages()
	{
		$rows = $this->Crm_model->packages();
        if($rows){
        echo "
        <h4 align='center' width='100%'>Availed packages</h4>
        <table style='background-color:#e7f2fd;white-space:nowrap;' class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
            <tr>
                <th scope='col'>Package name</th>
                <th scope='col'><i class='fas'>&#xf64a;</i> validity</th>
                <th scope='col'>No of services</th>
                <th scope='col'><i class='fas'>&#xf05a;</i> info</th>
                <th scope='col'><i class='fas'>&#xf156;</i> price</th>
                <th scope='col'>service</th>
                <th class='align-right' scope='cil'>action</th>
            </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->name."</td>
            <td>".date('d-F-Y', strtotime($r->validity))."</td>
            <td>".$r->number."</td>
            <td>".$r->info."</td>
            <td><i class='fas'>&#xf156;</i>".$r->price."</td>
            <td>".$r->service."</td>
            <td class='align-right'><a class='w3-button w3-gray mybtn' href='". base_url()."index.php/Customer/savereqpackage/req/".$r->id."'><i style='font-size:large;' class='material-icons'>&#xe163;</i> request</a></td>
        </tr>
              ";
        }
        echo "</table>";
      } else { echo "<p align='center'>No packages</p>"; }
	}

    public function requestservice()
    {
        $data['rows'] = $this->Crm_model->listservices();
        if($data['rows']){
            $this->load->view('customer/requestservice',$data);
        }
        else
        {
            echo "<p align='center'>No Services</p>";
        }
    }

    public function savereqservice()
    { $user = $this->session->userdata('user');

        if($this->uri->segment(3) == 'req')
        {
            $array = [
                        'customer' => $user['fullname'],
                        'custid' => $user['id'],
                        'service_id' => $this->uri->segment(4),
                        'status' => "requested"
            ];
            $this->Crm_model->savereqservice($array);
            echo "<p align='center'>Requested</p>
                  <p align='center'>Request <a href='".base_url()."index.php/Customer/services'>again</a></p>
            ";
        }
        else
        {
            $array = [
                        'customer' => $user['fullname'],
                        'custid' => $user['id'],
                        'service_id' => $this->input->post('service'),
                        'status' => "requested"
            ];

        $this->Crm_model->savereqservice($array);
        $data = ['rows'=>$this->Crm_model->listservices()];
        $this->load->view('customer/requestservice',$data); 
        }
    }

    public function requestpackage()
    {
        $data['rows'] = $this->Crm_model->packages();
        if($data['rows']){
            $this->load->view('customer/requestpackage',$data);
        }
        else
        {
            echo "<p align='center'>No Packages</p>";
        }
    }

    public function savereqpackage()
    { $user = $this->session->userdata('user');
        if($this->uri->segment(3) == 'req')
        {
            $pid = $this->Crm_model->pid($this->uri->segment(4))->name;
            $array = [
                        'customer' => $user['fullname'],
                        'custid' => $user['id'],
                        'pid' => $this->uri->segment(4),
                        'package' => $pid,
                        'status' => "requested"
            ];
            $this->Crm_model->savereqpackage($array);
            echo "<p align='center'>Requested</p>
                  <p align='center'>Request <a href='".base_url()."index.php/Customer/packages'>again</a></p>
            ";
        }
        else
        {
            $pid = $this->Crm_model->pid($this->input->post('package'))->name;
            $array = [
                        'customer' => $user['fullname'],
                        'custid' => $user['id'],
                        'pid' => $this->input->post('package'),
                        'package' => $pid,
                        'status' => "requested"
            ];
            $this->Crm_model->savereqpackage($array);
            $data = ['rows'=>$this->Crm_model->packages()];
            $this->load->view('customer/requestpackage',$data);
        }
    }

    public function history()
    {
        $this->load->view('customer/history');
    }

    public function viewhistory()
    { $user = $this->session->userdata('user');
        
        $rows = $this->Crm_model->history($user['id']);
        if($rows){
        echo "
        <table style='background-color:#e7f2fd;white-space:nowrap;' class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>service staff</th>
            <th scope='col'>staff id</th>
            <th scope='col'>service/package name</th>
            <th scope='col'>customer name</th>
            <th scope='col'>customer id</th>
            <th scope='col'><i class='fas'>&#xf879;</i> phone number</th>
            <th scope='col'><i class='fas'>&#xf274;</i> date and time of service</th>
            <th scope='col'><i class='far'>&#xf249;</i> notes</th>
            <th scope='col'>status</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->staff_name."</td>
            <td>".$r->staff_id."</td>";

            $iir = $this->Crm_model->getassrow($r->work_id);
            if($iir->type == "service"){ $table = "servicereq";

                $iiir = $this->Crm_model->getid($table,$iir->req_id);
                $sn = $this->Crm_model->getsn($iiir->service_id);
                echo"<td>"; if($sn){echo $sn->name;}else{echo "<text style='color:red;'>! removed</text>";} echo "</td>"; 
            }
            elseif($iir->type == "package"){ $table = "packagereq";

                $iiir = $this->Crm_model->getid($table,$iir->req_id);
                $pk = $this->Crm_model->getpn($iiir->pid);
                echo"<td>"; if($pk){echo $pk->name;}else{echo "<text style='color:red;'>! removed</text>";} echo "</td>";
            }
            
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
                echo "<td>".$ir->fullname."</td>";
            }
            else{
                echo "<td style='color:red;'>! removed user</td>";
            }
            echo "
            <td>".$r->customer_id."</td>";
            $ir = $this->Crm_model->getuser($r->customer_id);
            if($ir){
                if(!empty($ir->contact)) { echo "<td>".$ir->contact."</td>"; }
                else{echo "<td style='color:red;'>null !</td>"; }
            }
            else{
                echo "<td style='color:red;'>null !</td>";
                echo "<td style='color:red;'>null !</td>";
            }
            echo "
            <td>".date('d-F-Y', strtotime($r->date))."<br>".date('h:i sa', strtotime($r->date))."</td>
            <td>".$r->note."</td>
            <td>".$r->status."</td>
        </tr>
              ";
        }
        echo "</table>";
        }
        else{
            echo "<p align='center'>No service histoty</p>";
        }
    }

    public function edit()
    {
        $id = $this->uri->segment(3);
        $data = ['row'=>$this->Crm_model->getrow($id)];
        $this->load->view('editpass',$data);
    }

    public function edita()
    {   $user = $this->session->userdata('user');
        if($user && $user['privilage'] == array_keys(return_privilage())[4]){
            
        $id = $this->uri->segment(3);
        $op = $this->input->post('op');
        $np = $this->input->post('np');
        $cnp = $this->input->post('cnp');
        $row = $this->Crm_model->getrow($id);
        $data['row'] = $this->Crm_model->getrow($id);
        if (password_verify($op, $row->password)) {
            if ($np == $cnp) {
                $a = $this->input->post('fullname');
                $b = $this->input->post('gender');
                $c = $this->input->post('age');
                $d = $this->input->post('address');
                $e = $this->input->post('contact');
                $f = $this->input->post('email');
                $h = password_hash($cnp, PASSWORD_DEFAULT);
                $this->load->database();
                $this->load->model('Crm_model');
                $this->Crm_model->edita($id,$a,$b,$c,$d,$e,$f,$h);

                $this->session->sess_destroy();

                echo "
                <script type='text/javascript'>
                parent.window.location.reload();
                </script>
                ";

            }
            else{
                $data['msg'] = "New password not mach";
                $this->load->view('edit',$data);
            }
        }
        else{
            $data['msg'] = "Old password not mach";
            $this->load->view('edit',$data);
        }
        
    } else { echo "access denied"; } }

}