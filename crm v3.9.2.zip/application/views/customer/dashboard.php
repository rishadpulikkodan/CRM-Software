<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/anim.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
.mycard{
    margin:1%;
}
</style>
</head>
<body class='f1'>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#pk').load('<?= base_url()?>index.php/Customer/analytics/pk').fadeIn("slow");
      $('#ss').load('<?= base_url()?>index.php/Customer/analytics/ss').fadeIn("slow");
      $('#sh').load('<?= base_url()?>index.php/Customer/analytics/sh').fadeIn("slow");
      $('#ps').load('<?= base_url()?>index.php/Customer/analytics/ps').fadeIn("slow");
    },100);
</script>
<br/>
<br/>
<div class="container">
<div class="row">
  <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
	<div class="card mycard">
      <div class="card-header">
          <h5 class="card-title">Packages</h5>
      </div>
	  <div class="card-body">
	    <p class="card-text text-center">Availed packages</p>
	    <p class="card-text text-center" id='pk'></p>
	    <p class="text-center">
	    	<a href="<?= base_url()?>index.php/Customer/packages" class="btn btn-primary">view</a>
	    </p>
	    
	  </div>
	</div>
  </div>
  <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
	<div class="card mycard">
      <div class="card-header">
          <h5 class="card-title">Services</h5>
      </div>
	  <div class="card-body">
	    <p class="card-text text-center">Availed services</p>
	    <p class="card-text text-center" id='ss'></p>
	    <p class="text-center">
	    	<a href="<?= base_url()?>index.php/Customer/services" class="btn btn-primary">view</a>
	    </p>
	    
	  </div>
	</div>
  </div>
  <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
	<div class="card mycard">
      <div class="card-header">
          <h5 class="card-title">History</h5>
      </div>
	  <div class="card-body">
	    <p class="card-text text-center">Service history of compleated works</p>
	    <p class="card-text text-center" id='sh'></p>
	    <p class="text-center">
	    	<a href="<?= base_url()?>index.php/Customer/history" class="btn btn-primary">view</a>
	    </p>
	    
	  </div>
	</div>
  </div>
  <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
	<div class="card mycard">
      <div class="card-header">
          <h5 class="card-title">Pending</h5>
      </div>
	  <div class="card-body">
	    <p class="card-text text-center">Total pending works requested by you</p>
	    <p class="card-text text-center" id='ps'></p>
	  </div>
	</div>
  </div>
</div>
<!-- <div class="row">
<p class="text-center w-100">
<a class="w3-button w3-gray mybtn" href="<?= base_url()?>index.php/Customer/requestservice"><i style="font-size:large;" class="material-icons">&#xe163;</i> Request service</a>
&nbsp;
<a class="w3-button w3-gray mybtn" href="<?= base_url()?>index.php/Customer/requestpackage"><i style="font-size:large;" class="material-icons">&#xe163;</i> Request package</a>
</p>
</div> -->
</div>
</body>
</html>