<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>



<div class="w3-container">
  
  <div class="w3-card-4 f1 myform">

    <div class="w3-container w3-blue" style="border-radius: 10px 10px 0px 0px;">
      <h3>Send service request</h3>
    </div>

    <form class="w3-container" action="<?= base_url()?>index.php/Customer/savereqservice" method="POST" enctype="multipart/form-data">
    <p>
    <label>Select service</label>

      <select class='w3-input' name='service' required>
                  <option></option>
                  <?php
                  foreach($rows as $r)
                  {
                      echo "<option value='".$r->id."'>".$r->name."</option>";
                  }
                  ?>
      </select>
    </p>
    <p></p>
    
    <p align="right"><input class="w3-button w3-blue mybtn" type="submit" name="" value="Submit"></p>
    </form>
  </div>
</div>

</body>
</html> 