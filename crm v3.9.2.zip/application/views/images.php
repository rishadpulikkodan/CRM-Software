<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
	<title></title>
</head>
<style type="text/css">
img{
	width: 100%;
}
#imgs{
    margin: auto;
    width: 50%;
}
</style>
<body>

<a style="position: fixed;margin-left:85%;margin-right:auto;" href="javascript:history.back()" title="back"><i style="font-size:55px;" class="material-icons">&#xe5cd;</i></a>

<div id="imgs">
<?php
if($rows){
	foreach ($rows as $r) {
	echo "
		<img src='".base_url()."res/gallery/".$r->name."' /><br><br/>
	";
	}
}
else{
	echo "<p align='center'>No images about this service data</p>";
}
?>
</div>
</body>
</html>