<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
    a{
        color: blue !important;
    }
</style>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#ld').load('<?= base_url()?>index.php/Staff/viewpending').fadeIn("slow");
      $('#pc').load('<?= base_url()?>index.php/Staff/pendingc').fadeIn("slow");
    },500);
</script>
<div class="w3-container fh w-100">
        <h4 align="center">Pending works (<text id="pc"></text>)</h4>
    <div id="ld" class="table-responsive f2">
        
    </div>
</div>
</body>
</html>