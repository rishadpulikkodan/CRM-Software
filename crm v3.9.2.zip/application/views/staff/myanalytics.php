<?php
			echo "Pending ".$s;
?>