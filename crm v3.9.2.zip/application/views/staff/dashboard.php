<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>

<div class="w3-container">
  <div class='w-100 f1' style="height:25vh;">


    
<table>
	<tr>
		<td></td>
		<td></td>
	</tr>
</table>
    
  </div>
</div>

</body>
</html> 