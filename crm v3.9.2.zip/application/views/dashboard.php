<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/anim.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/dashboard.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
.mycard{
    margin:1%;
}
</style>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#bar').load('<?= base_url()?>index.php/Crm/analyticss/bar').fadeIn("slow");

      $('#mc').load('<?= base_url()?>index.php/Crm/analyticss/m').fadeIn("slow");
      $('#ac').load('<?= base_url()?>index.php/Crm/analyticss/a').fadeIn("slow");
      $('#sc').load('<?= base_url()?>index.php/Crm/analyticss/s').fadeIn("slow");
      $('#cc').load('<?= base_url()?>index.php/Crm/analyticss/c').fadeIn("slow");

      $('#pw').load('<?= base_url()?>index.php/Crm/analyticss/pw').fadeIn("slow");
      $('#cw').load('<?= base_url()?>index.php/Crm/analyticss/cw').fadeIn("slow");
      $('#ap').load('<?= base_url()?>index.php/Crm/analyticss/ap').fadeIn("slow");
      $('#as').load('<?= base_url()?>index.php/Crm/analyticss/as').fadeIn("slow");
      $('#rs').load('<?= base_url()?>index.php/Crm/analyticss/rs').fadeIn("slow");
    },100);
</script>

<!-- <p align="center" class="h4">Analytics</p>

<div class="container f1">
  <div class="row">
    <div class='col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12'>
      <div id='bar' class='barcontainer'>

      </div>
    </div>
  </div>
</div>

<br/>

<p align="center">
  <button style="background:#d8ffc7;" class="plate">compleated</button> <button style="background:#ffe8e8;" class="plate">penting</button>
  <button style="background:#ffd9f8;" class="plate">deleted</button> <button style="background:#d4dfff;" class="plate">total</button>
</p> -->

<br/>

<div class="container f1">
<div class="row">
    <div class='col-lg-4 col-12 col-xl-4 col-md-4 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf00c;</i> Compleated works
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="cw" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/reports" class="card-link">view</a> reports
          </div>
        </div>
    </div>
    <div class='col-lg-4 col-12 col-xl-4 col-md-4 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf017;</i> Pending works
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="pw" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/reports" class="card-link">view</a> reports
          </div>
        </div>
    </div>
    <div class='col-lg-4 col-12 col-xl-4 col-md-4 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf468;</i> Available packages
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="ap" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listpackages" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-4 col-12 col-xl-4 col-md-4 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0b1;</i> Available services
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="as" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listservices" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-4 col-12 col-xl-4 col-md-4 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf359;</i> Requests from customers
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="rs" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Acc_exe/requests" class="card-link">view</a>
          </div>
        </div>
    </div>
</div>
</div>

<br/>

<p align="center" class="h4">Users</p>
<div class="container f1">
<div class="row">
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-6'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> Managers
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="mc" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listusers/298" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-6'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> Account executives
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="ac" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listusers/951" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-6'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> Staffs
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="sc" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listusers/357" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-6'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> Customers
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="cc" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Crm/listusers/852" class="card-link">view</a>
          </div>
        </div>
    </div>
</div>
</div>





</body>
</html>