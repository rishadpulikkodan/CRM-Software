<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style type="text/css">
    a{
        color: blue !important;
    }
</style>
</head>
<body id="bd">
<div class="container f1 fh w-100">

  <div class='table-responsive'>
<?php
            if($custs)
            {
            echo "
            <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
            <thead class='thead-dark'>
            <tr>
                <th scope='col'>id</th>
                <th scope='col'><i class='fas'>&#xf007;</i> Customer name</th>
                <th scope='col'></th>
            </tr>
            </thead>";
            foreach($custs as $r)
            {
                    $cus = $this->Crm_model->invoget($r->cus_id);
                    if($cus)
                    {
                    echo "
                    <tr>
                        <td>".$cus->cus_id."</td>
                        <td>".$cus->cus_name."</td>
                        <td align='right'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/Crm/viewsubinvo/".$cus->cus_id."/".$cus->cus_name."'><i class='fas'>&#xf06e;</i> view</a></td>
                    </tr>
                    ";
                    }
            }
            echo "</table>";
            }
            else{ echo "<p align='center'>0 results</p>"; }
?>
  </div>

</div>
</body>
</html>