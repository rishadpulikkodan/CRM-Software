<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
            $('#contents').load('<?= base_url()?>index.php/Crm/loadinvoices/<?=$this->uri->segment(3)?>').fadeIn("slow");
    },500);
</script>
<div class="container fh w-100">
<a class="f1" style="position: fixed;margin-left:95%;margin-right:auto;" href="javascript:history.back()" title="back"><i class='fas' style="font-size: 25px;">&#xf053;</i></a>


    <p align="center">edit invoices</p>

<div class='table-responsive'>
  <div id="contents">

  </div>
</div>

    <div class="form-row">
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for='pkg'>Select packages</label>
            <?php if($pkgs) { ?>
            <select id='pkg' class='form-control'>
                <option></option>
                <?php foreach($pkgs as $r) { echo "
                <option value='".$r->id."'>".$r->name."</option>"; } ?>
            </select>
            <?php } else { echo "0 results"; } ?>
            <small class='form-text text-muted'>Select a package</small>
        </div>
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for="pkgprice">Price</label>
            <input type="number" class="form-control" id="pkgprice" min='0' required>
            <small class='form-text text-muted'>Enter package price</small>
        </div>
        <div class="col-3 col-sm-2 col-md-2 col-lg-2 col-xl-2 mb-3">
            <label for='adpk'>&nbsp;</label>
            <button id='adpk' type='button' class='form-control btn btn-primary'>Add</button>
            <small class='form-text text-muted'>&nbsp;</small>
        </div>
    </div>

    <div class="form-row">
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for='srv'>Select packages</label>
            <?php if($servs) { ?>
            <select id='srv' class='form-control'>
                <option></option>
                <?php foreach($servs as $r) { echo "
                <option value='".$r->id."'>".$r->name."</option>"; } ?>
            </select>
            <?php } else { echo "0 results"; } ?>
            <small class='form-text text-muted'>Select a service</small>
        </div>
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for="srvprice">Price</label>
            <input type="number" class="form-control" id="srvprice" min='0' required>
            <small class='form-text text-muted'>Enter service price</small>
        </div>
        <div class="col-3 col-sm-2 col-md-2 col-lg-2 col-xl-2 mb-3">
            <label for='adss'>&nbsp;</label>
            <button id='adss' type='button' class='form-control btn btn-primary'>Add</button>
            <small class='form-text text-muted'>&nbsp;</small>
        </div>
    </div>

<!-- other expences strt -->

    <div class="form-row">
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for='exp'>Other expences</label>
            <input type="text" id="exp" class='form-control' />
            <small class='form-text text-muted'>add other expences if</small>
        </div>
        <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2 mb-3">
            <label for='expamd'>price</label>
            <input type="number" id="expamd" class='form-control' min='0' />
            <small class='form-text text-muted'>enter amount</small>
        </div>
        <div class="col-3 col-sm-2 col-md-2 col-lg-2 col-xl-2 mb-3">
            <label for='adexp'>&nbsp;</label>
            <button id="adexp" type='button' class='form-control btn btn-primary'>Add</button>
            <small class='form-text text-muted'>&nbsp;</small>
        </div>
    </div>

<!-- other expences end -->

<p align="center"><a class="btn btn-primary" href="javascript:history.back()">done</a></p>

</div>
<div id="h"></div>
<div id="reminvo"></div>
<script type="text/javascript">
$(document).ready(function(){

  $("#adss").click(function(){
    if($("#srv").val() != "" && $('#sc').val() != "")
    {
        var cus = $('#sc').val();
        var sid = $('#srv').val();
        var srvprice = $("#srvprice").val();
        $('#h').load('<?=base_url()?>index.php/Crm/addinvo/s/' + cus + '/' + sid + '/' + 'sgst' + '/' + '<?=$this->uri->segment(3)?>' + '/' + srvprice + '/a');
        $("#srv").val("");
        $("#srvprice").val("");
    }
    else
    {
        alert("fill the fields");
    }
  });

  $("#adpk").click(function(){
    if($("#pkg").val() != "" && $('#sc').val() != "")
    {
        var cus = $('#sc').val();
        var pid = $('#pkg').val();
        var pkgprice = $("#pkgprice").val();
        $('#h').load('<?=base_url()?>index.php/Crm/addinvo/p/' + cus + '/' + pid + '/' + 'pgst' + '/' + '<?=$this->uri->segment(3)?>' + '/' + pkgprice + '/a');
        $("#pkg").val("");
        $("#pkgprice").val("");
    }
    else
    {
        alert("fill the fields");
    }
  });

  $("#adexp").click(function(){
    if($("#exp").val() != "")
    {
        var cus = $('#sc').val();
        var exp = $('#exp').val();
        var expamd = $('#expamd').val();
        $('#h').load('<?=base_url()?>index.php/Crm/addinvo/e/' + cus + '/' + exp + '/' + expamd + '/' + '<?=$this->uri->segment(3)?>' + '/a');
        $("#exp").val("");
        $('#expamd').val("");
    }
    else
    {
        alert("fill the fields");
    }
  });

});
</script>
<script type="text/javascript">
function reminvo(x){
    $("#reminvo").load("<?=base_url()?>index.php/Crm/removeinvoice/" + x );
}
</script>
</body>
</html>