<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    a{
        color: blue !important;
    }
</style>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#ld').load('<?= base_url()?>index.php/Crm/viewverifications').fadeIn("slow");
    },500);
</script>
<div class="w3-container fh w-100 f1">

    <div class='f1' style="width:100%;height:100vh;display:none;z-index:1;position:fixed;margin-left:auto !important;margin-right:auto !important;padding-right:auto !important;padding-left:auto !important;background: radial-gradient(rgba(0, 0, 0, 0.4), transparent);" id="demo" onclick="cancel()">

        <div style="background:rgba(255,255,255,1);width:50%;margin-left:auto !important;margin-right:auto !important;margin-top:10%;border: 5px solid white;border-radius: 15px;box-shadow: 0px 0px 15px grey;height:118px;">
            <table width="100%">
                <tr>
                    <td>
                        <iframe src="" name="alert" style="width:100%;height:118px;border:none;" scrolling="no"></iframe>
                    </td>
                    <td align="right" valign="bottom">
                        <button style="margin-bottom: 18px;" class="w3-button w3-red mybtn" type="button" onclick="cancel()">close</button>
                    </td>
                </tr>
            </table>
        </div>
    </div>
<br/>
<p align="center" class="h4">Verifications</p>
    <div class='table-responsive' id="ld">
        
    </div>
</div>
<script>
function deletereq() {
  document.getElementById('demo').style.display = 'block'; 
}
function cancel() {
  document.getElementById('demo').style.display = 'none'; 
}
</script>
</body>
</html>