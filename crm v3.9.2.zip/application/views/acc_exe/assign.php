<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>res/css/anim.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>

<div class="w3-container">
  
  <div class="w3-card-4" style="margin-top:5%;width:75%;margin-left:auto;margin-right:auto;">

    <div class="w3-container w3-blue">
      <h4>Assign services</h4>
    </div>

    <form style="background:#e7f1fd;" class="w3-container" action="<?= base_url()?>index.php/Acc_exe/saveassign" method="POST" enctype="multipart/form-data">

    <p align="center">
    <label>select type</label></p>
    <p align="center">
    <input onclick="sh()" id="r1" type="radio" name="r" value="service" required><label for="r1">services</label> &nbsp; 
    <input onclick="hs()" id="r2" type="radio" name="r" value="package" required><label for="r2">packages</label>
    </p>

    <p class="f1" id="p1" style="display:none;">
    <label>select service</label>
    <select id="s1" name="sa" class="w3-input" required>
      <option></option>
    <?php
    foreach($s as $r)
    {
      $service = $this->Crm_model->servicerow($r->service_id)->name;
      $customer = $this->Crm_model->getuser($r->custid)->fullname;
      echo "<option value='".$r->id."'>".$service." from ".$customer."</option>";
    }
    ?>
    </select>
    </p>

    <p class="f1" id="p2" style="display:none;">
    <label>select package</label>
    <select id="s2" name="sb" class="w3-input" required>
      <option></option>
    <?php
    foreach($p as $r)
    {
      $package = $this->Crm_model->pid($r->pid)->name;
      $customer = $this->Crm_model->getuser($r->custid)->fullname;
      echo "<option value='".$r->id."'>".$package." from ".$customer."</option>";
    }
    ?>
    </select>
    </p>

    <br/>

    <p>
    <label>Select corresponding staff</label>
    <select title="Select corresponding / responsible staff" list="staff_id" name="staff_id" class="w3-input" required>
      <option placeholder="Select Customer"></option>
    <?php
    foreach($rows as $r)
    {
      echo "<option value='".$r->id."'>".$r->fullname."</option>";
    }
    ?>
    </select>
    </p>
    
    <p><input class="w3-button w3-blue" type="submit" name="" value="Assign"><?php if(! empty($msg)) { echo $msg; } ?></p>
    </form>
  </div>
</div>
<script type="text/javascript">
var pa = document.getElementById("p1");
var pb = document.getElementById("p2");
var sa = document.getElementsByTagName("select")[0];
var sb = document.getElementsByTagName("select")[1];
function sh() {
  pb.style.display = "none";
  sb.removeAttribute("required");

  pa.style.display = "block";
  sa.setAttribute("required");
}
function hs() {
  pa.style.display = "none";
  sa.removeAttribute("required");

  pb.style.display = "block";
  sb.setAttribute("required");
}
</script>
</body>
</html> 