<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style type="text/css">
    a{
        text-decoration:none !important;
    }
    </style>
</head>
<body>
<div class="w3-container fh f1">
	<div class="row fh">

        <div id="btnCls" style="width:100%;">
          <p style="text-align: center;width: 100%;">
          <a href="<?= base_url()?>index.php/Acc_exe/createcustomer" class="w3-bar-item w3-button btn" target="p"><i class='fas'>&#xf234;</i> Create customer</a>
          <a href="<?= base_url()?>index.php/Acc_exe/clistusers/852" class="w3-bar-item w3-button btn active" target="p"><i class='fas'>&#xf03a;</i> List customers</a>
          </p>
        </div>
        
        <div style="width: 100%;">
          <iframe class="fh w-100" style="border:none;width: 100%;height: 90vh;" src="<?= base_url()?>index.php/Acc_exe/clistusers/852" name="p"></iframe>
        </div>

	</div>
</div>

    <!-- Optional JavaScript -->
<script type="text/javascript">
// Add active class to the current button (highlight it)
var header = document.getElementById("btnCls");
var btns = header.getElementsByClassName(" btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  
  var current = document.getElementsByClassName("active");
  current[0].className = current[0].className.replace(" active", "");
  this.className += " active";
  });
}
</script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>