<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/admin.css">
    <style>
	.element::-webkit-scrollbar { display: none; !important }
	.element{ overflow: -moz-scrollbars-none; }
	.red{color:red;}
    </style>
    <title></title>
</head>
<body>
<div class="container fh f1">
	<div class="row fh">

			<div style="margin-left:auto;margin-right: auto;"> 
				<form style="margin-top: 5%;" action="<?=base_url()?>index.php/Acc_exe/signinc" method="post">
				  <?php if(!empty($msg)) { echo "<text style='color:red;'>".$msg."</text>";} ?>
				  <div class="group">
				  	<label>Full name <text class="red">*</text></label>
				    <input type="text" name="fullname" required />
				    <?php echo form_error('fullname', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>Gender <text class="red">*</text></label>
				    <select name="gender" required>
				    	<option></option>
				    	<option>Male</option>
				    	<option>Female</option>
				    	<option>Other</option>
				    </select>
				    <?php echo form_error('gender', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>Age <text class="red">*</text></label>
				    	<input id="age" type="number" name="age" min="18" max="95" minlength="2" maxlength="2" required />
				  		<?php echo form_error('age', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>Address <text class="red">*</text></label>
				    	<input type="text" name="address" required />
				    	<?php echo form_error('address', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>Contact <text class="red">*</text></label>
				    	<input type="number" name="contact" minlength="10" maxlength="12" required />
				    	<?php echo form_error('contact', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>Email <text class="red">*</text></label>
				    	<input type="email" name="email"/>
				    	<?php echo form_error('email', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class='group'>
				    <label>Location <text class="red">*</text></label>
				    	<input type='url' name='location' />
				    	<?php echo form_error('location', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				    <label>User name <text class="red">*</text></label>
				    	<input type="text" name="username" required />
				    	<?php echo form_error('username', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				  	<label>Password <text class="red">*</text></label>
				    <input type="password" name="password" minlength="8" maxlength="12" required>
				    <?php echo form_error('password', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div class="group">
				  	<label>Confirm password <text class="red">*</text></label>
				    <input type="password" name="cpassword" minlength="8" maxlength="12" required>
				    <?php echo form_error('cpassword', '<text style="color:red;">', '</text>'); ?>
				  </div>
				  <div>
				  <button type="submit" class="button buttonBlue" name="signin">Create
				    <div class="ripples buttonRipples"><span class="ripplesCircle"></span></div>
				  </button>
				  <?php if(!empty($msg)) { echo "<text style='color:red;'>".$msg."</text>";} ?>
				</div>
				</form>
			</div>

	</div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>