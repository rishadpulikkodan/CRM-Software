<!DOCTYPE html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#cc').load('<?= base_url()?>index.php/Acc_exe/cc').fadeIn("slow");
      $('#sc').load('<?= base_url()?>index.php/Acc_exe/sc').fadeIn("slow");
    },100);
</script>
<style>
.mycard{
    margin:1%;
}
</style>
<body>

<div class="container f1">
<div class="row">
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> my ustomers
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="cc" class="card-text"></p>
            <a href="<?= base_url()?>index.php/Acc_exe/clistusers/852" class="card-link">view</a>
          </div>
        </div>
    </div>
    <div class='col-lg-6 col-12 col-xl-6 col-md-6 col-sm-12'>
        <div class="card mycard px-0">
            <div class="card-header">
                <i class='fas'>&#xf0c0;</i> Staffs
            </div>
          <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted"></h6>
            <p id="sc" class="card-text"></p>
            
          </div>
        </div>
    </div>
</div>
</div>

<!--     <div class="f1" style="width: 90px;margin: 3% auto;">
        <a style="color: black !important;" href="<?= base_url()?>index.php/Acc_exe/clistusers/852">
        <button style="background: transparent;border:none;border-radius: 50%;height: 90px;width: 90px;outline:none;box-shadow: 0px 0px 10px grey;margin: 5% auto;">
            <text id="cc"></text><br/>
            <i class='fas'>&#xf0c0;</i><br/>
            customers<br/>
        </button>
        </a>
        
        <button style="background: transparent;border:none;border-radius: 50%;height: 90px;width: 90px;outline:none;box-shadow: 0px 0px 10px grey;margin: 5% auto;">
            <text id="sc"></text><br/>
            <i class='fas'>&#xf0c0;</i><br/>
            staffs
        </button>
    </div> -->
</body>
</html>