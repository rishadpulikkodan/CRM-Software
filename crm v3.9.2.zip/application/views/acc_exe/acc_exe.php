<!DOCTYPE html>
<html>
<head>
<title>Account executive | <?php echo $username; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
<link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/three.css">
<link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
<link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/resp.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#ap').load('<?= base_url()?>index.php/Acc_exe/approvalc').fadeIn("slow");
      $('#re').load('<?= base_url()?>index.php/Acc_exe/nreqc').fadeIn("slow");
    },100);
</script>
<div class="w3-sidebar w3-bar-block w3-card w3-animate-left myside" id="mySidebar">

  <div style="padding:0;" class="w3-bar-item">
    <table style="width:100%;">
      <tr>
        <td align="left">
    <button style="width:50%;white-space:nowrap;text-align:left;" class="w3-button"
  onclick="w3_close()"><i class='fas'>&#xf053;</i> Close</button>
        </td>
        <td align="right">

                <div class="dropdown">
                    <!-- three dots -->
                    <div class="showLeft btn-right icons dropbtn f1" onclick="showDropdown()">
                      <li></li>
                      <li></li>
                      <li></li>
                    </div>
                    <!-- menu -->
                    <div id="myDropdown" class="dropdown-content f1">
                        <?php echo "<a onclick='mclose()' target='main' href='".base_url()."index.php/Acc_exe/edit/".$id."'>Edit <i class='fas fa-pen'></i></a>"; ?>
                        <a href="<?= base_url()?>index.php/Crm/logout">Logout &nbsp;<i class="glyphicon glyphicon-log-out"></i></a>
                    </div>
                </div>
        </td>
      </tr>
    </table>
  </div>

  <text style="text-align: center;font-size: large;color: gray;" class="w3-bar-item">Account executive</text>
  <div class="w3-bar-item mydiv">
    <img class="myimg" src="<?= base_url()?>res/img/user.png" />
  </div>
  <text style="text-align: center;" class="w3-bar-item"><?php echo $username; ?></text>
  <!-- <text class="w3-bar-item"><b>Analytics</b></text> -->

  <div class="w3-bar-item" id="lt"></div>

  <div id="btnCls">
  <a onclick="mclose()" target="main" class="w3-bar-item w3-button btn active" href="<?= base_url()?>index.php/Acc_exe/dashboard"><i class='fas'>&#xf466;</i> Dashboard</a>
  <a onclick="mclose()" target="main" class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Acc_exe/approvals"><i class='fas'>&#xf00c;</i> <b id="ap"></b></a>
  <a onclick="mclose()" target="main" class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Acc_exe/requests"><i class='fas'>&#xf359;</i> <b id="re"></b></a>
  <a onclick="mclose()" target="main" class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Acc_exe/Customers"><i class='fas'>&#xf500;</i> <b>Customers</b></a>
  <a onclick="mclose()" target="main" class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Acc_exe/assign"><i style="font-size:large;" class="material-icons">&#xe85e;</i> <b>Assign services</b></a>
  <a class="w3-bar-item w3-button btn" href='<?= base_url()?>index.php/Crm/logout'><i class="glyphicon glyphicon-log-out"></i> <b>Logout</b></a>
  </div>

</div>

<div id="area" onmouseover="w3_close()" onclick="w3_close()" style="width: 50%;height: 100vh;position: fixed;margin-left: 50%;z-index: 1;"></div>

<div id="main">

  <button id="openNav" class="w3-button w3-xlarge myb" onclick="w3_open()"><i class='fas f2'>&#xf054;</i></button>
  <button id="openNavM" class="w3-button w3-xlarge myb" onmouseover="w3_open()"><i class='fas f2 ra'>&#xf054;</i></button>

<div class="w3-container">
<iframe style="border:none;width:100%;height:100vh;" src="<?= base_url()?>index.php/Acc_exe/dashboard" name="main"></iframe>
</div>

</div>

<?php $this->load->view('js'); ?>

</body>
</html>