<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style type="text/css">
    a{
        text-decoration:none !important;
    }
    </style>
    <title></title>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#sr').load('<?= base_url()?>index.php/Acc_exe/servicereqc').fadeIn("slow");
      $('#pr').load('<?= base_url()?>index.php/Acc_exe/packagereqc').fadeIn("slow");
    },100);
</script>
<div class="w3-container fh">
	<div class="row fh f1">
        
        <div id="btnCls">
          <p style="text-align: center;width: 100%;">
          <a href="<?= base_url()?>index.php/Acc_exe/servicerequests" class="w3-bar-item w3-button btn active" target="p"><text id="sr"></text></a>
          <a href="<?= base_url()?>index.php/Acc_exe/packagerequests" class="w3-bar-item w3-button btn" target="p"><text id="pr"></text></a>
          </p>
        </div>
        
        <div style="width: 100%;">
          <iframe class="fh w-100" style="border:none;width: 100%;height: 90vh;" src="<?= base_url()?>index.php/Acc_exe/servicerequests" name="p"></iframe>
        </div>

	</div>
</div>
<script type="text/javascript">
// Add active class to the current button (highlight it)
var header = document.getElementById("btnCls");
var btns = header.getElementsByClassName(" btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  
  var current = document.getElementsByClassName("active");
  current[0].className = current[0].className.replace(" active", "");
  this.className += " active";
  });
}
</script>
</body>
</html>