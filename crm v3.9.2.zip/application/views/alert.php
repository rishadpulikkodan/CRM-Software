<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel='stylesheet' type='text/css' href='<?=base_url()?>res/css/crm.css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style type="text/css">
@media screen and (min-width: 300px) {
  div.example {
    font-size: 16px;
  }
}

@media screen and (max-width: 300px) {
  div.example {
    font-size: 8px;
  }
}
</style>
</head>
<body>

	<p id='s' style='display:none;' align='center'>Deleted successfully</p>
	<p style="white-space: nowrap;margin: auto;" id='h'>write a reason to delete</p>

	<form id="frm" action="<?=base_url()?>index.php/crm/reject/<?=$id?>" method='post'>
	<input id="ht" type="text" name="reason" style="width:100%;" required />
	<p align='right' style='position:fixed;width:100%;'>
	<button type="submit" id='hb' class='w3-button w3-gray mybtn'><i class='fas'>&#xf2ed;</i> Delete</button>
	</p>
	</form>

<script>
$(document).ready(function(){
  $("#frm").submit(function(){
	document.getElementById('hb').style.display = 'none';
	document.getElementById('ht').style.display = 'none';
	document.getElementById('h').style.display = 'none';
	document.getElementById('s').style.display = 'block';
  });
});
</script>
</body>
</html>