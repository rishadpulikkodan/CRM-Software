<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
    content="Customer relationship management" />
    <meta name="theme-color" content="#d0e3fb">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/login.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/anim.css">
    <title>CRM Login</title>
<style type="text/css">
@media only screen and (min-width: 960px) {
	#h{
		display:block;
	}
}

@media only screen and (max-width: 960px) {
	#h{
		display:none;
	}
}
</style>
</head>
<body style="margin:0px;" class="">
<div class="container fh">
	<div class="row fh">

		<div id="h" class="col-lg-6 col-xl-6 f1">
			<div style="margin: 34vh 75px;">
				<img width="100%" src="<?= base_url() ?>res/img/section2.svg" />
			</div>
		</div>


		<div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
			<div>
				<form action="<?=base_url()?>index.php/crm/login" method="post">
				  <div class="group">
				    <input type="text" name="name" value="<?php if(!empty($name)){echo$name;} ?>" required placeholder="Username"><span class="bar"></span>
				  </div>
				  <div class="group">
				    <input type="password" name="password" minlength="8" maxlength="12" required placeholder="Password"><span class="bar"></span>
				  </div>
				  <div>
				  <button type="submit" class="button buttonBlue">LogIn
				    <div class="ripples buttonRipples"><span class="ripplesCircle"></span></div>
				  </button>
				  <?php if(empty($msg))
				  {
				  	echo "&nbsp;";
				  }
				  else{
				  	echo "<text style='color:red;'>".$msg."</text>";
				  }
				   ?>
				 </div>
				</form>
				<p align="center" style="color:gray;font-size: 10px;white-space: nowrap;">Customer Relations Management</p>
			<div class="col-3 col-sm-3 col-md-2 col-lg-2 col-xl-2 f1" style="margin:auto;">
				
				<p style="font-size: 11px;" align="center">Powered By</p>
				<div class="">
					<img src="<?= base_url() ?>res/img/saventure-logo2.png" width="100%" />
				</div>
			</div>

			</div>

		</div>

	</div>
</div>
</body>
</html>