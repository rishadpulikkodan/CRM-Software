<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
    a{
        color: blue !important;
    }
</style>
</head>
<body>
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#ld').load('<?= base_url()?>index.php/Staff/viewstatus').fadeIn("slow");
    },500);
</script>
<div class="w3-container fh w-100 f1">
  

    <?php
        if($rows){
        echo "
        <div class='table-responsive'>
        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>name</th>
            <th scope='col'>validity</th>
            <th scope='col'>number</th>
            <th scope='col'>info</th>
            <th scope='col'>price</th>
            <th scope='col'>service</th>
            <th scope='col' colspan='2' style='text-align:center;'><i class='fas'>&#xf7d9;</i> actions</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->name."</td>
            <td>".date('d-F-Y', strtotime($r->validity))."</td>
            <td>".$r->number."</td>
            <td>".$r->info."</td>
            <td>".$r->price."</td>
            <td>".$r->service."</td>
            <td align='right'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/crm/editpackage/".$r->id."'><i class='fas'>&#xf304;</i> edit</a></td>
            <td align='left'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/crm/deletepackage/".$r->id."'><i class='fas'>&#xf1f8;</i> delete</a></td>
        </tr>";
        }
        echo "</table>
        </div>";
        }
        else{
            echo "<p align='center'>0 results</p>";
        }
    ?>
  
</div>
</body>
</html>