<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/admin.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/anim.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>res/css/crm.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <script>
	function showDiv(divId, element)
	{
	    document.getElementById(divId).style.display = element.value == 852 ? 'block' : 'none';
	}
    </script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
	.element::-webkit-scrollbar { display: none; !important }
	.element { overflow: -moz-scrollbars-none; }
    a{
        text-decoration:none !important;
    }
    </style>
    <title></title>
</head>
<body class="f1">
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#m').load('<?= base_url()?>index.php/Crm/analyticss/m').fadeIn("slow");
      $('#a').load('<?= base_url()?>index.php/Crm/analyticss/a').fadeIn("slow");
      $('#s').load('<?= base_url()?>index.php/Crm/analyticss/s').fadeIn("slow");
      $('#c').load('<?= base_url()?>index.php/Crm/analyticss/c').fadeIn("slow");
    },100);
</script>
			<div style="height: 10%; width: 100%" class="table-responsive f1">
        <div id="btnCls">
				<p align="center" style="width: 100%;">
					<a class="w3-bar-item w3-button btn active" href="<?= base_url()?>index.php/Crm/newuser" target="u"><i class='fas'>&#xf234;</i> New user</a>
					<a class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Crm/listusers/298" target="u">managers (<text id="m"></text>)</a>
					<a class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Crm/listusers/951" target="u">account executives (<text id="a"></text>)</a>
					<a class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Crm/listusers/357" target="u">service staffs (<text id="s"></text>)</a>
					<a class="w3-bar-item w3-button btn" href="<?= base_url()?>index.php/Crm/listusers/852" target="u">customers (<text id="c"></text>)</a>
				</p>
        <div>
			</div>
			<iframe style="border:none;height:95vh;width:100%;" src="<?= base_url()?>index.php/Crm/newuser" name="u"></iframe>
    <!-- Optional JavaScript -->
<script type="text/javascript">
// Add active class to the current button (highlight it)
var header = document.getElementById("btnCls");
var btns = header.getElementsByClassName(" btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  
  var current = document.getElementsByClassName("active");
  current[0].className = current[0].className.replace(" active", "");
  this.className += " active";
  });
}
</script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
</body>
</html>