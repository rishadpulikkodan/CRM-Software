<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/crm.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style>
    a{
        color: blue !important;
    }
    .rt{
        text-align-last: right;
    }
</style>
</head>
<body>
<div class="w3-container fh w-100 f1">
  

    <?php
        if($rows){
        echo "
        <div class='table-responsive'>
        <table class='table table-bordered table-sm table-hover' style='white-space:nowrap;'>
        <thead class='thead-dark'>
        <tr>
            <th scope='col'>Slno</th>
            <th scope='col'>name</th>
            <th scope='col'><i class='fas'>&#xf156;</i> price</th>
            <th scope='col' colspan='2' style='text-align:center;'><i class='fas'>&#xf7d9;</i> actions</th>
        </tr>
        </thead>";
        foreach($rows as $r)
        {
        echo "
        <tr>
            <td>".$r->id."</td>
            <td>".$r->name."</td>
            <td> <i class='fas'>&#xf156;</i> ".$r->price."</td>
            <td class='rt' align='right'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/crm/editservice/".$r->id."'><i class='fas'>&#xf304;</i> edit</a></td>
            <td align='left'><a class='w3-button w3-gray mybtn' href='".base_url()."index.php/crm/deleteservice/".$r->id."'><i class='fas'>&#xf1f8;</i> delete</a></td>
        </tr>";
        }
        echo "</table>
        </div>";
        }
        else{
            echo "<p class='f1' align='center'>0 results</p>";
        }

    ?>
    <?php echo $links; ?>
</div>
</body>
</html>