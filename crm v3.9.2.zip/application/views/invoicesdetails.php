<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>res/css/anim.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
<style type="text/css">
    a{
        color: blue !important;
    }
    #print{
    border: 0.5px solid gray;
    border-radius: 10px;
    padding: 50px;
    }

</style>
</head>
<body id="bd">
<script type="text/javascript">
  var auto_refresh = setInterval(
    function ()
    {
      $('#ld').load('<?= base_url()?>index.php/Crm/viewinvoicesdetails/<?=$id?>').fadeIn("slow");
        $('#total').load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>').fadeIn("slow");

        if($("#switch").prop("checked") == true){
            $('#gtotal').load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>/gst').fadeIn("slow");
            $("#gst").slideDown();
            $("#gst").load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>/sc').fadeIn("slow");
        }
        else if($("#switch").prop("checked") == false){
            $('#gtotal').load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>').fadeIn("slow");
        }
    },600);
</script>

<a class="f1" style="position: fixed;margin-left:95%;margin-right:auto;" href="<?=base_url()?>index.php/Crm/viewsubinvo/<?=$this->uri->segment(4)?>" title="back"><i class='fas' style="font-size: 25px;">&#xf053;</i></a>
<br/>
<br/>

<div class="container f2 fh w-100">

 <div id="print">

    <table class="w-100">
        <tr>
            <td align="left">
                <h2><u>Invoice</u>
                    <text style="font-size: 18px;">#<text id=""><?=$this->uri->segment(3)?></text></text>
                </h2>
            </td>
            <td width="25%">
                <img width="100%" src="<?= base_url()?>res/img/logo.png"/>
            </td>
        </tr>
        <tr>
            <td colspan="2"><hr style="border: 1px solid black;width:100%;"></hr></td>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <td>
                <text class='f1'>
                <?php $adm = $this->session->userdata('user'); ?>
                <b>&nbsp;&nbsp;&nbsp;<u>From</u></b></br>
                <b>Company : Abc</b></br>
                <b>Phone : <?=$adm['contact']?></b></br>
                <b>Address : <?=$adm['address']?></b></br>
                <b>&nbsp;</b></br>
                <b>&nbsp;</b></br>
                </text>
            </td>
            <td style="width:25%;">
                <?php echo "
                <text>
                    <b>&nbsp;&nbsp;&nbsp;<u>To</u></br>
                    <b>Name : </b>".$cus->fullname."</br>
                    <b>id : </b>".$cus->id."</br>
                    <b>date : </b>".$this->uri->segment(5)."</br>
                    <b>Phone : </b>".$cus->contact."</br>
                    <b>Address : </b>".$cus->address."</br>
                </text>
                "; ?>
            </td>
        </tr>
    </table>

    <br/><br/>

  <div class='table-responsive'>
    <div id="ld">
        
    </div>
  </div>
    <br/><br/>

    <p align="right">
        <br/>
        Sub total : <text id="total"></text><br/>

        <text style="display:none;" id="gst"></text><br/>

        <b>Grand total : <text id="gtotal"></text></b>
    </p>

 </div>

<br/><br/>

<table align="right">
    <tr>
        <td>
            <div class="custom-control custom-switch">
                <input type="checkbox" class="custom-control-input" id="switch">
                <label style="font-weight:unset !important;" class="custom-control-label" for="switch" id="ss">Include GST</label>
            </div>
        </td>
        <td> &nbsp; </td>
        <td>
            <a class='btn btn-primary' href="<?= base_url()?>index.php/Crm/editinvoice/<?=$this->uri->segment(3)?>/<?=$this->uri->segment(4)?>/">edit</a>
        </td>
        <td> &nbsp; </td>
        <td>
            <button onclick="print()" class='btn btn-primary'>print</button>
        </td>
    </tr>
</table>
    <iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
</div>

<script type="text/javascript">
$(document).ready(function(){

  $("#switch").click(function(){
      if($("#switch").prop("checked") == true){
          $('#gtotal').load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>/gst').fadeIn("slow");
          $("#gst").slideDown();
          $("#gst").load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>/sc').fadeIn("slow");
          $("#ss").html("Exclude GST");
      }
      else if($("#switch").prop("checked") == false){
          $('#gtotal').load('<?= base_url()?>index.php/Crm/invoicetotal/<?=$this->uri->segment(3)?>').fadeIn("slow");
          $("#gst").slideUp();
          $("#ss").html("Include GST");
      }
  });

});
</script>
<script src="<?= base_url()?>res/js/printThis.js"></script>
<script>
    function print()
    {
        $('#print').printThis({
        debug: false,               // show the iframe for debugging
        importCSS: true,            // import parent page css
        importStyle: '<style> .rm{ display:none !important; visibility:hidden !important; color:white !important;} a{color:white !important;} </style>',         // import style tags
        printContainer: true,       // print outer container/$.selector
        loadCSS: 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css',                // path to additional css file - use an array [] for multiple
        pageTitle: 'invoices',              // add title to print page
        removeInline: false,        // remove inline styles from print elements
        removeInlineSelector: '*',  // custom selectors to filter inline styles. removeInline must be true
        printDelay: 100,            // variable print delay
        header: 'Invoices',               // prefix to html
        footer: null,               // postfix to html
        base: false,                // preserve the BASE tag or accept a string for the URL
        formValues: true,           // preserve input/form values
        canvas: false,              // copy canvas content
        doctypeString: '<!DOCTYPE html>', // enter a different doctype for older markup
        removeScripts: false,       // remove script tags from print content
        copyTagClasses: false,      // copy classes from the html & body tag
        beforePrintEvent: null,     // callback function for printEvent in iframe
        beforePrint: null,          // function called before iframe is filled
        afterPrint: null            // function called before iframe is removed
        });
    }
</script>
</body>
</html>