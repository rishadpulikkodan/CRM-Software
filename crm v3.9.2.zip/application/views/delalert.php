<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel='stylesheet' type='text/css' href='<?=base_url()?>res/css/crm.css'>
<link rel='stylesheet' type='text/css' href='<?=base_url()?>res/css/admin.css'>
<style type="text/css">
@media screen and (min-width: 300px) {
  div.example {
    font-size: 16px;
  }
}

@media screen and (max-width: 300px) {
  div.example {
    font-size: 8px;
  }
}
</style>
</head>
<body>
	<p id='s' style='display:none;' align='center'>Deleted successfully</p>
	<p style="white-space: nowrap;" id='h'>Delete "<?=$na?>" .?</p>
	
	<p align='right' style='position:fixed;width:100%;'>
	<a id='hb' onclick='change()' class='w3-button w3-gray mybtn' href='<?=base_url()?>index.php/crm/removeuser/<?=$ur?>/<?=$id?>'><i class='fas'>&#xf2ed;</i> Delete</a>
	</p>
<script>
function change() {
	document.getElementById('hb').style.display = 'none';
	document.getElementById('h').style.display = 'none';
	document.getElementById('s').style.display = 'block';
}
</script>
</body>
</html>