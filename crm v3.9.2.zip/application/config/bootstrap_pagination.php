<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
// application/config/bootstrap_pagination.php
	    $config['full_tag_open'] = '<nav aria-label="Page navigation example pagination-small pagination-sm  pagination-centered"><ul class="pagination justify-content-center">';
	    $config['full_tag_close'] = '</ul></nav>';
	    $config['page_query_string'] = TRUE;
	    $config['prev_link'] = '&lt; Prev';
	    $config['prev_tag_open'] = '<li>';
	    $config['prev_tag_close'] = '</li>';
	    $config['next_link'] = 'Next &gt;';
	    $config['next_tag_open'] = '<li>';
	    $config['next_tag_close'] = '</li>';
	    $config['cur_tag_open'] = '<li class="active"><a href="#">';
	    $config['cur_tag_close'] = '</a></li>';
	    $config['num_tag_open'] = '<li class="page-item">';
	    $config['num_tag_close'] = '</li>';
?>